
/* Print out a table of logarithms.
 */

class MathTable {
	public static void main(String[] args) {
		for(int i = 0; i <= 1000; i++) {
			double x = i / 1000.0;
			System.out.format("ln(%1.4f) = %f\n", x, Math.log(x));
		}
	}
}


