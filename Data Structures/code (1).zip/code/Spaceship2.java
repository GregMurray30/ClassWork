class Spaceship2 {
	public static void main(String[] args) {
		double[] spaceship = { 3.1, 0.0 };
		double[] planet = { 10.5, -3.3 };
		
		// Start at planet
		spaceship[0] = planet[0];
		spaceship[1] = planet[1];
		
		// Hyperdrive in x dimension
		spaceship[0] += 100.0;
		
		// Where is the planet?
		System.out.println("Planet is at " + planet[0] + 
			", " + planet[1]);
	}
}
