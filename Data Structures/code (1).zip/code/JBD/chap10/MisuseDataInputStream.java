//MisuseDataInputStream.java - doesn't read correctly
import java.io.*;
import tio.*;

class MisuseDataInputStream {
  public static void main(String[] args)
    throws IOException
  {
    DataInputStream input = 
      new DataInputStream(System.in);
    System.out.println("Enter 4 integers.");
    for (int i = 0; i < 4; i++){
      int value = input.readInt();
      System.out.println("You entered " + value);
    }
  }
}
