//HelloFileRead.java - reading a text file
import tio.*;

class HelloFileRead {
  public static void main(String[] args)
  {
    ReadInput in = new ReadInput("hello.txt");
    System.out.println(in.readLine());
  }
}

