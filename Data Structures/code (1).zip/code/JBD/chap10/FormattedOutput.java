//FormattedOutput.java - demo of formatted text output
import tio.*;
class FormattedOutput {  
  public static void main(String[] args)
        throws java.io.IOException
  {
    int x = 1, y = 22;
    double z = 4.5678E-20;
    FormattedWriter out = 
           new FormattedWriter(System.out);
    out.setWidth(10);
    out.setDigits(2);
    out.printf("col1");
    out.printf("col2");
    out.printfln("col3");
    out.printf(x);
    out.printf(y);
    out.printfln(z);
  }
}
