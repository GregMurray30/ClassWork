//WordCount.java - count the words in a file
import tio.*;

class WordCount {
  public static void main(String[] args)
  { 
    ReadInput in = new ReadInput("sample.txt");
    int count = 0;
    while (in.hasMoreElements()){
      String word = in.readWord();
      count++;
    }
    System.out.println("There were "+count+" words.");
  }
}
