//HelloFile.java - writing to a file
import java.io.*;

class HelloFile {
  public static void main(String[] args)
        throws java.io.IOException
  { 
    PrintWriter out = 
     new PrintWriter(new FileWriter("hello.txt"));
    out.println("Hello, file system!");
    out.close();
  }
}
