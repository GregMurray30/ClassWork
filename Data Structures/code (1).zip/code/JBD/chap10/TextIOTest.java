//TextIOTest.java
import java.io.*;
import tio.*;

class TextIOTest {
  public static void main(String[] args)
             throws IOException
  {
    PrintWriter out = new PrintWriter(
                      new FileWriter("test.txt"));
    double x = 1.0;
    int count = 10;
    out.println(count);
    for (int i = 0; i < count; i++){
      out.println(x);
      x = x / 3.0;
    }
    out.close();
    ReadInput in = new ReadInput("test.txt");
    count = in.readInt();
    for (int i = 0; i < count; i++){
      System.out.println(in.readDouble());
    }
  }
}
