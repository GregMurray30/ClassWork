//FileReadInput - reading primitive values from a file
import tio.*;

class FileReadInput {
  public static void main(String[] args)
  {
    ReadInput in = new ReadInput("sample.txt");
    int x = in.readInt();
    double y = in.readDouble();
    String s = in.readWord();
    System.out.println("x = "+x);
    System.out.println("y = "+y);
    System.out.println("s = "+s);
  }
}
