// Echo.java - echo file contents to the screen
import java.io.*;

class Echo {
  public static void main(String[] args)
       throws IOException
  {
    if (args.length < 1){
      System.out.println("Usage: java Echo filename");
      System.exit(0);
    }
    BufferedReader input =
        new BufferedReader(new FileReader(args[0]));
    String line = input.readLine();
    while (line != null) {
      System.out.println(line);
      line = input.readLine();
    }
  }
}
