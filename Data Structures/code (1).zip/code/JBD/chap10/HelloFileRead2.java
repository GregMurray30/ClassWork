//HelloFileRead2.java - using standard classes to read
import java.io.*;

class HelloFileRead2 {
  public static void main(String[] args)
        throws IOException
  {
    BufferedReader in = new BufferedReader(
                 new FileReader("hello.txt"));
    System.out.println(in.readLine());
  }
}
