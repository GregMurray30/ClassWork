/* HelloWorld.java
 * Purpose: 
 *   The classic "Hello, world!" program.
 *   It prints a message to the screen.
 * Author: Jane Programmer
 *       as derived from Kernighan and Richie
 */
class HelloWorld {
  public static void main (String[] args) {
    System.out.println("Hello, world!");
  }
}
