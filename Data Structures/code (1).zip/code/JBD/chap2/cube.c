#include <stdio.h> 
int main(void) {
  double side = 3.5;    /* side of a cube */
  double volume;

  printf("The side of my cube is %f feet.\n", side);
  volume = side * side * side; 
  printf("The cubes volume is %f cubic feet.\n",
              volume);
  return 0;
}
