/* Hello World In C
 * Purpose: 
 *   The classic "Hello, world!" program.
 *   It simply prints a message to the screen.
 * Author: 
 *    Jane Programmer
 *       as derived from Kernighan and Richie
 */

#include <stdio.h>     /* needed for IO */
int main(void) {
   printf("Hello, world!\n");
   return 0;           /* unneeded in Java */
}
