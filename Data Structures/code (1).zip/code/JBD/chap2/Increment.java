//Increment.java - demonstrate incrementing
class Increment {
  public static void main(String[] args) {
    int i = 0;
    System.out.println("i = " + i);
    i = i + 1;
    System.out.println("i = " + i);
    i++;
    System.out.println("i = " + i);
    i++;
    System.out.println("i = " + i);
  }
}
