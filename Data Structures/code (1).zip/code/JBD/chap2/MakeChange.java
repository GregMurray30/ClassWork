// MakeChange.java - change in dimes and pennies
import tio.*;     // use the package tio 

class MakeChange {
  public static void main (String[] args) {
    int price, change, dimes, pennies;

    System.out.println("type price (0:100):");
    price = Console.in.readInt(); 
    change = 100 - price;        //how much change
    dimes = change / 10;         //number of dimes
    pennies = change % 10;       //number of pennies
    System.out.print("The change is : ");
    System.out.println(dimes + " dimes " +
                       pennies + " pennies");
  }
}
