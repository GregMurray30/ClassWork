/* To place this applet in a web page, add the
   following two lines to the html document for the
   page.
  <applet code="FirstApplet.class"
  width=500 height=200></applet> 
*/
// AWT and Swing together comprise the collection of
// classes used for building graphical Java programs
import java.awt.*; //required for programs that draw
import javax.swing.*; //required for Swing applets
public class FirstApplet extends JApplet {
  public void paint(Graphics g) {
    // draw a line from the upper left corner to
    // 100 pixels below the top center of the Applet
    g.drawLine(0,0,250,100);
    // draw a line from the end of the previous line
    // up to the top center of the Applet
    g.drawLine(250,100,250,0);
    // draw an oval inscribed in an invisible
    // rectangle with its upper left corner at the
    // intersection of the two lines drawn above
    g.drawOval(250,100,200,100);
  }
}
