#include <stdio.h> 
int main(void) {
   printf("Hello, world!\n");
   printf("My name is George.\n");
   printf("Yada Yada Yada ...\n");
   return 0;
}
