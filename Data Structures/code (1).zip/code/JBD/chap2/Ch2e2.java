// Ch2e2.java - more syntax errors
class Ch2e2 {
  public static void main(String[] args) {
    int count = 1, i = 3,
    System.out.println("count + i = ",  count + i);
  }
}
