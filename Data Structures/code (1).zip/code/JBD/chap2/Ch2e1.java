// Ch2e1.java - fixing syntax errors
Class Ch2e1 {
  public static void main(String[] args) {
    System.out.println(hello, world);
  }
