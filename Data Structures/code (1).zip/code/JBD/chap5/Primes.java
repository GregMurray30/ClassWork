//Sieve of Eratosthenes for Primes up to 100.
class Primes {
  public static void main(String[] args) {
    boolean[] sieve = new boolean[100];
    int i;
    System.out.println(" Table of primes to 100.");
    for (i = 0; i < 100; i++)
      sieve[i] = true;
    for (int j = 2; j < Math.sqrt(100); j++)
      if (sieve[j])
         crossOut(sieve, j, j + j);
    for (i = 0; i < 100; i++) //print primes
      if (sieve[i])
         System.out.print(" " + i); 
  }
  public static void crossOut(boolean[] s,
                 int interval, int start) 
  {
   for (int i = start; i < s.length; i += interval)
      s[i] = false;
  }
}
