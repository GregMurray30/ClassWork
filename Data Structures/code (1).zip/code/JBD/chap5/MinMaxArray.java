class MinMaxArray {

  public static void main(String[] args) {
    int[] array = { 10, 20, -5, 999, 30 };

    int[] result = minMaxArray(array);
    System.out.println("min = " + result[0]);
    System.out.println("max = " + result[1]);
  }
static int[] minMaxArray(int[] data) {
  int[] minMax = new int[2];    //store min and max
  // the length must be even
  int midPoint = data.length/2;

  // loop puts the min somewhere in the first half
  // and the max somewhere in the second half
  for (int i = 0; i < midPoint; i++)
    if (data[i] > data[midPoint + i ])
      swap(i, midPoint + i, data);
  // loop finds the min which must be in first half
  minMax[0] = data[0];
  for (int i = 1; i < midPoint; i++)
    if (data[i] < minMax[0])
      minMax[0] = data[i];
  // loop finds the max which must be in second half
  minMax[1] = data[midPoint];
  for (int i = midPoint + 1; i < data.length; i++)
    if (data[i] > minMax[1])
      minMax[1] = data[i];
  return minMax;
}
static void swap(int i, int j, int[] data) {
  int temp = data[i];

  data[i] = data[j];
  data[j] = temp;
}
}
