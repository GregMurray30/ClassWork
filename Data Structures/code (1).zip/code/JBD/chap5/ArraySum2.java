// ArraySum2.java - sum the elements in an array
//    using a method
class ArraySum2 {
  public static void main(String[] args) {
    int[] data1 = {1, 2, 3, 4, 5, 6, 7};
    int[] data2 = {16, 18, 77};

    System.out.println("data1:" + sum(data1));
    System.out.println("data2:" + sum(data2));
  }
  // sum the elements in an array
  static int sum (int[] a) {
    int sum = 0;
    
    for (int i = 0; i < a.length; i++)
      sum = sum + a[i];
    return sum;
  }
}
