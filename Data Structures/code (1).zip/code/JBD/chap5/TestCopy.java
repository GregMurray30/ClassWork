// TestCopy.java - demonstrate that array
//    parameters can be modified
class TestCopy {
  public static void main(String[] args) {
    int[] data1 = {1, 2, 3, 4, 5, 6, 7};
    int[] data2 = {8, 9, 10, 11, 12, 13, 14};
    copy(data1, data2);
    System.out.println("data1:");
    for (int i = 0; i < data1.length; i++)
      System.out.println(data1[i]);
    System.out.println("data2:");
    for (int i = 0; i < data2.length; i++)
      System.out.println(data2[i]);
  }
  static void copy(int[] from, int[] to) {
    for (int i = 0; i < from.length; i++)
      to[i] = from[i];
  }
}
