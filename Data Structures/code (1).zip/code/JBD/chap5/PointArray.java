// PointArray.java-example array nonprimitive values
import java.awt.Point;

class PointArray {
  public static void main(String[] args) {
    Point[] triangle;

    triangle = new Point[3];
    triangle[0] = new Point(10,20);
    triangle[1] = new Point(35,90);
    triangle[2] = new Point(20, 85);
    for (int i = 0; i < triangle.length; i++)
      System.out.println(triangle[i]);
    translate(triangle,100,200);
    for (int i = 0; i < triangle.length; i++)
      System.out.println(triangle[i]);
  }
  public static void translate(Point[] points,
			       int deltaX, int deltaY)
  {
    for (int i = 0; i < points.length; i++)
      points[i].translate(deltaX, deltaY);
  }
}
