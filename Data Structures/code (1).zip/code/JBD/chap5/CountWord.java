//CountWord.java 
import tio.*;
public class CountWord {
  public static void main(String[] args) {
    String input;
    char[] buffer;
    System.out.println("type in line" );
    input = Console.in.readLine();
    System.out.println(input);
    buffer = input.toCharArray();
    System.out.println("word count is " +
                        wordCount(buffer));
  }
  //word are separated by nonalphabetic characters
  public static int wordCount(char[]buf) {
    int position = 0, wc = 0;
    while (position < buf.length) {
      while (position < buf.length &&
             !isAlpha(buf[position])) 
        position++;
      if (position < buf.length)
        wc++;
      while (position < buf.length &&         
                   isAlpha(buf[position])) 
        position++;
    }
    return wc;
  }
   public static boolean isAlpha(char c) {
     return (c >= 'a' && c <= 'z') ||
            (c >= 'A' && c <= 'Z') ;
  }
}
