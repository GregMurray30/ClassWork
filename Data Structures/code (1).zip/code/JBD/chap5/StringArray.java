// StringArray.java - uses a string array initializer
class StringArray {
  public static void main(String[] args) {
    String[] myStringArray = { "zero", "one", "two",
        "three", "four", "five", "six", "seven",
        "eight", "nine"};
    for (int i = 0; i < myStringArray.length; i++)
      System.out.println(myStringArray[i]);
  }
}
