// ArrayTest.java - minimum and maximum of an array
import tio.*;

class ArrayTest {
  public static void main(String[] args) {
    int[] data;
    int n;
    System.out.println("Enter size of data[]:");
    n = Console.in.readInt();
    data = new int[n];
    System.out.println("Enter " + n + " integers:");
    readArray(data);
    printArray(data, "My Data");
    System.out.println("minimum is " + minimum(data)
        + "   maximum is " + maximum(data));
  }
  // fill an array by reading values from the console
  static void readArray(int[] a) {
    for ( int i = 0; i < a.length; i++) {
      a[i] = Console.in.readInt();
    }
  }
  // find the maximum value in an array
  static int maximum(int[] a) {
    int  max = a[0]; //initial max value
    for (int i = 1; i < a.length; i++)
      if (a[i] > max)
        max = a[i];
    return max;
  }
  // find the minimum value in an array
  static int minimum(int[] a) {
    int  min = a[0]; //initial max value
  
    for (int i = 1; i < a.length; i++)
      if (a[i] < min)
        min = a[i];
    return min;
  }
  // print the elements of an array to the console
  static void printArray(int[] a, String arrayName) {
    System.out.println(arrayName );
    for (int i = 0; i < a.length; i++)
      System.out.print(a[i] + "  ");
    System.out.println();
  }
}
