// TwoD.java - simple example of two-dimensional array
class TwoD {
  public static void main(String[] args) {
    int[][] data = new int[3][5];
    for (int i = 0; i < data.length; i++) {
      System.out.print("Row " + i + ":   ");
      for (int j = 0; j < data[i].length; j++) {
        data[i][j] = i * j;
        System.out.print(data[i][j] + ", ");
      }
      System.out.println();
    }
  }
}

