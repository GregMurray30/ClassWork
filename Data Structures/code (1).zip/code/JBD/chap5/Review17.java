class Review17 {
  public static void main(String[] args) {
    int n = 20;
    boolean[] sieve = new boolean[n];
    int i;

    for (i = 0; i < sieve.length;  i++) 
      sieve[i] = true;
    for (int j = 2; j < 8; j++)
      if (sieve[j])
        crossOut(sieve, j, j + j);
    for (i = 0; i < sieve.length; i++)
      if (sieve[i])
        System.out.println("i is " + i); 
  }
  public static void crossOut(boolean[] s, 
           int interval, int start)
  {
    for (int i = start; i < s.length; i += interval)
      s[i] = false;
  }
}
