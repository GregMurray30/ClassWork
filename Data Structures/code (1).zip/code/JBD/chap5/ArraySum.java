// ArraySum.java - sum the elements in an array and
//    compute their average
class ArraySum {
  public static void main(String[] args) {
    int[] data = {11, 12, 13, 14, 15, 16, 17};
    int sum = 0;
    double average;
    for (int i = 0; i < 7; i++) {
      sum = sum + data[i];
      System.out.print(data[i] + ", ");
    }
    average = sum / 7.0;
    System.out.println("\n\n sum = " + sum
        + " average = " + average);
  }
}
