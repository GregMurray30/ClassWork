class Review11 {
  public static void main(String[] args) {
    int[] data = {1,3,5,7,9,11};
    int sum = 0;
      for (int i = 1; i < data.length; i++) {
        sum = sum + (data[i] + data[i - 1]);
        System.out.println("sum  = " + sum);
      }
  }
}
