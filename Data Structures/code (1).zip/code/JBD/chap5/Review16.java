class Review16 {
  static int goo(int i){
    return i + 2;
  }
  static void hoo(int[] d, int n)  {
    for (int i = 0; i < d.length; i++)
      d[i] = goo(n);   
  }
  public static void main(String[] args) {
    int i = 2;
    int[] a = {1, 2, 3};
    System.out.println("goo =" + goo(i));
    hoo(a, 1);
    hoo(a, i);
    for (i = 0; i < a.length; i++)
      System.out.println(i + " : " + a[i]);
  }
}
