import java.awt.*;
import javax.swing.*;

class DrawText extends JComponent
{
  public void paint(Graphics g) {
    g.drawString("Starts at (10, 20)", 10, 20);
    g.fillRect(10, 20, 4, 4);
    g.setFont(new Font("TimesRoman", Font.BOLD, 20));
    g.drawString("20pt bold starting at (100, 40)",
		 100, 40);
    g.fillRect(100, 40, 4, 4);
  }
  public Dimension getMinimumSize()
  { return dim;
  }
  public Dimension getPreferredSize()
  { return dim;
  }
  private Dimension dim = new Dimension(220,100); 
}
