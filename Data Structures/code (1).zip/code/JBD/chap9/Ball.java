//Ball.java - dummy class just to get
//  BouncingBall to compile for test purposes.

class Ball {
  public void repaint(){};
}
