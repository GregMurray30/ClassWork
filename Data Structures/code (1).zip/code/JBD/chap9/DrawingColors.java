import java.awt.*;
import javax.swing.*;

class DrawingColors
{
  public static void main(String[] args)
  {
    JFrame frame = new JFrame("DrawingColors");
    Container pane = frame.getContentPane();
    pane.add(new DrawColors());
    frame.pack();
    frame.show();
  }
}
