//DrawOvals.java
import java.awt.*;
import javax.swing.*;

class DrawOvals extends JComponent
{
  public void paint(Graphics g) {
    g.drawRect(10, 10, 100, 60);
    g.drawOval(10, 10, 100, 60);
  }
  public Dimension getMinimumSize()
  { return dim;
  }
  public Dimension getPreferredSize()
  { return dim;
  }
  private Dimension dim = new Dimension(500,100); 
}
