//Nesting.java - nest a JPanel container in a JFrame
import java.awt.*;
import javax.swing.*;

class Nesting {
  public static void main(String[] args) {
    JFrame frame = new JFrame("Nesting containers");
    Container pane = frame.getContentPane();
    JPanel panel = new JPanel();
    panel.setLayout(new GridLayout(4, 1));
    panel.add(new JButton("One"));
    panel.add(new JButton("Two"));
    panel.add(new JButton("Three"));
    panel.add(new JButton("Four"));
    pane.add(panel, BorderLayout.WEST);
    pane.add(new Star(), BorderLayout.CENTER);
    frame.pack();
    frame.show();
  }
}
