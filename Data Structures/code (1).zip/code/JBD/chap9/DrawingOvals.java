import java.awt.*;
import javax.swing.*;

class DrawingOvals
{
  public static void main(String[] args)
  {
    JFrame frame = new JFrame("DrawingOvals");
    Container pane = frame.getContentPane();
    pane.add(new DrawOvals());
    frame.pack();
    frame.show();
  }
}
