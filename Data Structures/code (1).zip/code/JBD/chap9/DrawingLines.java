//DrawingLines.java - demo drawLine() and
//                         drawPloyline()
import java.awt.*;
import javax.swing.*;

class DrawingLines {
  public static void main(String[] args) {
    JFrame frame = new JFrame("DrawingLines");
    Container pane = frame.getContentPane();
    pane.add(new DrawTriangle());
    frame.pack();
    frame.show();
  }
}
