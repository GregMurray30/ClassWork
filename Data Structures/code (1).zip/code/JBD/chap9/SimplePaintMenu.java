// SimplePaintMenu.java - add a menu to SimplePaint2
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class SimplePaintMenu {
  public static void main(String[] args) {
    JFrame frame = new JFrame("SimplePaintMenu");
    Container pane = frame.getContentPane();
    // create the canvas and mouse listener
    // just as in SimplePaint2
    DrawingCanvas2 canvas = new DrawingCanvas2();
    PaintListener3 painter = new PaintListener3();
    canvas.addMouseMotionListener(painter);
    pane.add(canvas);
    // create the menu bar and top level menus
    JMenuBar menuBar = new JMenuBar();
    JMenu fileMenu = new JMenu("File");
    fileMenu.setMnemonic('F');
    JMenu optionsMenu = new JMenu("Options");
    optionsMenu.setMnemonic('O');
    menuBar.add(fileMenu);
    menuBar.add(optionsMenu);
    frame.setJMenuBar(menuBar);

    // add items to the fileMenu
    JMenuItem exit = new JMenuItem("Exit",'x');
    fileMenu.add(exit);
    exit.addActionListener(new GoodBye());
    
    // create and add items to the optionsMenu
    // the first item is a submenu for pen size
    JMenu penAdjusterMenu = new JMenu("Pen size");
    penAdjusterMenu.setMnemonic('P');
    // create and add items to the pen size sub menu
    JMenuItem smallPen = new JMenuItem("Small", 'S');
    JMenuItem mediumPen = new JMenuItem("Medium",'M');
    JMenuItem largePen = new JMenuItem("Large", 'L');
    penAdjusterMenu.add(smallPen);
    penAdjusterMenu.add(mediumPen);
    penAdjusterMenu.add(largePen);
    // add a listener to the pen selection items
    PenAdjuster penAdjuster = 
        new PenAdjuster(painter);
    smallPen.addActionListener(penAdjuster);
    mediumPen.addActionListener(penAdjuster);
    largePen.addActionListener(penAdjuster);
    optionsMenu.add(penAdjusterMenu);
    // for demo purposes add second (unused) item
    optionsMenu.add(new JMenuItem("Other",'O'));

    frame.pack();
    frame.show();
  }  
}
