//GameBoard.java
import java.awt.*;

class GameBoard extends Canvas { 
  // the example supports only two valid states
  public static final byte INVALID = -1;
  public static final byte STATE0 = 0;
  public static final byte STATE1 = 1;

  public GameBoard(int width, int height,
                   byte[][] board) {
    this.board = board;
    setSize(new Dimension(width, height));
  }
  // draw the cells of the board
  public void paint(Graphics g) {
    for (int row = 0; row<board.length; row++)
      for (int col=0; col < board[row].length; col++){
        select_color(g, board[row][col]);
        g.fillRect(col * cellWidth, 
                   row * cellHeight,
                   cellWidth, cellHeight);
      }
  }
  /* The default update() redraws the entire display
   * using the background color, then calls paint().
   * To avoid the flicker of background color,
   * we override update() to just call paint(). 
   * This is recommended whenever paint() redraws
   * all pixels.
   */
  public void update(Graphics g) {
    paint(g);
  }
  public Dimension getMinimumSize() {
    return dim;
  }
  public Dimension getPreferredSize() {
    return getMinimumSize();
  }
  public void setBounds(int x, int y,
                        int width, int height)
  {
    dim = new Dimension(width, height);
    //adjust cell size to fill the new board size
    cellWidth = 
        Math.round((float)width / board.length);
    cellHeight = Math.round(
                     (float)height / board[0].length);
    super.setBounds(x, y, width, height);
    repaint();
  }
  public void setCell(int row, int col, byte value) {
    board[row][col] = value;
  }
  public byte getCell(int row, int col) {
    return board[row][col];
  }
  public int getCellWidth() { return cellWidth; }
  public int getCellHeight() { return cellHeight; }
  private void select_color(Graphics g, byte cell) {
    if (cell == STATE0)
      g.setColor(Color.white);
    else 
      g.setColor(Color.black);
  }
  private byte[][] board;
  private int cellWidth, cellHeight;
  private Dimension dim;
}
