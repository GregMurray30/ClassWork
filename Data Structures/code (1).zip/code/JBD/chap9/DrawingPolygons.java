import java.awt.*;
import javax.swing.*;

class DrawingPolygons
{
  public static void main(String[] args)
  {
    JFrame frame = new JFrame("DrawingPolygons");
    Container pane = frame.getContentPane();
    pane.add(new DrawPolygons());
    frame.pack();
    frame.show();
  }
}
