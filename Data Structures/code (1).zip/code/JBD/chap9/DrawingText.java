import java.awt.*;
import javax.swing.*;

class DrawingText
{
  public static void main(String[] args)
  {
    JFrame frame = new JFrame("DrawingText");
    Container pane = frame.getContentPane();
    pane.add(new DrawText());
    frame.pack();
    frame.show();
  }
}
