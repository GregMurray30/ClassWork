import java.awt.*;
import javax.swing.*;

class DrawColors extends JComponent
{
  public void paint(Graphics g) {
    g.setColor(Color.gray.brighter());
    g.fillRect(10, 10, 200, 100);
    g.setColor(Color.gray);
    g.fillRect(20, 20, 180, 80);
    g.setColor(Color.gray.darker());
    g.fillRect(30, 30, 160, 60);
    g.setColor(Color.black);
    g.drawRect(10, 10, 200, 100);
  }
  public Dimension getMinimumSize()
  { return dim;
  }
  public Dimension getPreferredSize()
  { return dim;
  }
  private Dimension dim = new Dimension(220,120); 
}
