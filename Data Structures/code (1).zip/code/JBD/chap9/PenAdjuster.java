// PenAdjuster.java - pass pen adjustment requests
//     to the painter
import java.awt.event.*;

class PenAdjuster implements ActionListener {
  private Painter painter;
  PenAdjuster(Painter thePainter) {
    painter = thePainter;
  }
  public void actionPerformed(ActionEvent e) {
    painter.setPenSize(e.getActionCommand());
  }
}
