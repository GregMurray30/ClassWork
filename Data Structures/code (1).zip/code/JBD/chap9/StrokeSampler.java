//StrokeSampler.java - examples of some Java2D strokes
import java.awt.*;
import javax.swing.*;

class StrokeSampler extends JComponent {

  public void paint(Graphics g) {
    Graphics2D g2d = (Graphics2D)g;

    // draw some rectangles with wide lines
    g2d.setStroke(wideStroke);
    g2d.drawRect(10, 10, 100, 60);
    g2d.setStroke(mediumStroke);
    g2d.drawRoundRect(120, 10, 100, 60, 40, 20);

    // draw some lines with round ends/joints
    int[] xcoords = {30, 60, 90};
    int[] ycoords = {90, 140, 90};
    g2d.setStroke(wideRound);
    g2d.drawPolyline(xcoords, ycoords, 3);

    // draw some lines with bevel joints
    for (int i = 0; i < xcoords.length; i++)
      xcoords[i] = xcoords[i] + 110;
    g2d.setStroke(wideBevel);
    g2d.drawPolyline(xcoords, ycoords, 3);

    // use a dot-dash stroke
    g2d.setStroke(dotDashStroke);
    g2d.drawRect(10, 170, 100, 60);
    g2d.drawRoundRect(120, 170, 100, 60, 40, 20);
  }
  static final BasicStroke wideStroke = 
    new BasicStroke(8.0f);
  static final BasicStroke mediumStroke =
    new BasicStroke(4.0f);
  static final BasicStroke wideRound = 
    new BasicStroke(16.0f,
            BasicStroke.CAP_ROUND /* end style */,
            BasicStroke.JOIN_ROUND /* join style */);

  static final BasicStroke wideBevel = 
    new BasicStroke(16.0f,
            BasicStroke.CAP_BUTT /* end style */,
            BasicStroke.JOIN_BEVEL /* join style */);
  static float[] dotDash = {10.0f, 5.0f, 5.0f, 5.0f};
  static final BasicStroke dotDashStroke = 
    new BasicStroke(4.0f /*width*/,
            BasicStroke.CAP_BUTT /*end style*/,
            BasicStroke.JOIN_MITER /*join style*/,
            1.0f /*miter trim limit */,
            dotDash /* pattern array */,
            0.0f /* offset to start of pattern */);
  public Dimension getMinimumSize() {
    return new Dimension(230, 240);
  }
  public Dimension getPreferredSize() {
    return getMinimumSize();
  }
}
