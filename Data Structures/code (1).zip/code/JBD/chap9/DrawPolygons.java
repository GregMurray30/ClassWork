import java.awt.*;
import javax.swing.*;

class DrawPolygons extends JComponent
{
  public void paint(Graphics g) {
    Polygon p = new Polygon();
    p.addPoint(10, 10);
    p.addPoint(60, 30);
    p.addPoint(40, 50);
    p.addPoint(25, 40);
    g.drawPolygon(p); // draw a Polygon object
    // draw a polygon using 2 arrays
    int[] x = {110, 160, 140, 125};
    int[] y = {10, 30, 50, 40};
    g.fillPolygon(x, y, 4);
    //move 200 pixels right and 20 down
    p.translate(200, 20);
    g.drawPolygon(p); // draw translated polygon
  }
  public Dimension getMinimumSize()
  { return dim;
  }
  public Dimension getPreferredSize()
  { return dim;
  }
  private Dimension dim = new Dimension(500,70); 
}
