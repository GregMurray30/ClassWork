//PlotTest.java
import java.awt.*;
import javax.swing.*;

class PlotTest {
  public static void main(String[] args) {
    Function f = new SinFunction();
    JFrame frame = new JFrame("PlotTest");
    Container pane = frame.getContentPane();
    Plot plot = new Plot(f, 0, 2 * Math.PI, 0.1);
    pane.add(plot);
    frame.pack();
    frame.show();
  }
}
