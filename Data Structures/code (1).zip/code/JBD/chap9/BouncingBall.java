//BouncingBall.java - driver for ball simulation
class BouncingBall {
  public static void main(String[] args)
     // the following is needed when calling sleep
     // see Chapter 11 for more about exceptions
    throws InterruptedException
  {
    Ball ball = new Ball();
    // code to create a JFrame, add ball to its
    // container pane and show the JFrame goes here
    Thread self = Thread.currentThread();
    while (true) {
      //call some method in Ball to set new position
      ball.repaint();
      self.sleep(100);//pauses 1/10th second
      // code to update position and velocity here
    }
  }
}
