//StrokeTest.java - examples of some Java2D strokes
import java.awt.*;
import javax.swing.*;

class StrokeTest
{
  public static void main(String[] args)
  {
    JFrame frame = new JFrame("StrokeTest");
    Container pane = frame.getContentPane();
    pane.add(new StrokeSampler());
    frame.pack();
    frame.show();
  }
}
