// PaintListener3.java - paints on an DrawingCanvas2,
// and it's associated offscreen image.
// Adds a setPenSize() method to PaintListener2.
import java.awt.*;
import java.awt.event.*;

public class PaintListener3 extends PaintListener2
    implements Painter
{
  // specify one of three pen sizes, 
  // Small, Medium or Large
  // radius and diameter are inherited
  public void setPenSize(String size) {
    if (size.equals("Small")) {
        radius = 0;
        diameter = 1;
    }
    else if (size.equals("Medium")) {
      radius = 3;
      diameter = radius * 2;
    }
    else if (size.equals("Large")) {
      radius = 6;
      diameter = radius * 2;
    }
  }  
}
