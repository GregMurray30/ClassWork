//SinFunction.java
class SinFunction implements Function {
  public double valueAt(double x) {
    return Math.sin(x);
  }
}
