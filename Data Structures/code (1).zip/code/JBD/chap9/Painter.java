// Painter.java - 
//   in practice this interface would contain
//   additional methods such as for changing pen
//   shape, color, pattern etc.
interface Painter {
  public void setPenSize(String size);
}
