//HelloButton.java
import javax.swing.*;
import java.awt.*; 
public class HelloButton3 { 
  public static void main(String[] args) { 
    JFrame frame = new JFrame("HelloButton");
    Container pane = frame.getContentPane();
    JButton hello = new JButton("Hello, world 1!");
    pane.add(hello);
    JButton more = new JButton("Hello, world 2!");
    pane.add(more); 
    JButton end = new JButton("Hello, world 3!");
    pane.add(end); 
    frame.pack(); 
    frame.show(); 
  } 
}
