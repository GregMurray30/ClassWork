//DrawRectangles.java
import java.awt.*;
import javax.swing.*;

class DrawRectangles extends JComponent
{
  public void paint(Graphics g) {
    g.drawRect(0, 0, 100, 60);
    g.drawRoundRect(110, 0, 100, 60, 40, 20);
    g.setColor(Color.gray);
    g.drawOval(170, 40, 40, 20);
  }
 public Dimension getMinimumSize()
  {
    return dim;
  }
  public Dimension getPreferredSize()
  {
    return dim;
  }
  private Dimension dim = new Dimension(220,70); 
}
