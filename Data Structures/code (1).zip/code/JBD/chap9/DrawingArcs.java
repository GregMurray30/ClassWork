import java.awt.*;
import javax.swing.*;

class DrawingArcs
{
  public static void main(String[] args)
  {
    JFrame frame = new JFrame("DrawingArcs");
    Container pane = frame.getContentPane();
    pane.add(new DrawArcs());
    frame.pack();
    frame.show();
  }
}
