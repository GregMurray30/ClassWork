//DrawTriangle.java - two ways to draw a triangle
import java.awt.*;
import javax.swing.*;

class DrawTriangle extends JComponent {

  public void paint(Graphics g) {
    g.drawLine(10, 10, 100, 60);
    g.drawLine(100, 60, 50, 80);
    g.drawLine(50, 80, 10, 10);
    int[] x = {120, 140, 160, 180, 200};
    int[] y = {10, 80, 10, 80, 10};
    g.drawPolyline(x, y, 5);
  }
  public Dimension getMinimumSize() {
    return dim;
  }

  public Dimension getPreferredSize() {
    return dim;
  }

  private Dimension dim = new Dimension(220, 100); 
}
