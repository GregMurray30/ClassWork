// GameEventHandler2.java - demo MouseAdapter
import java.awt.event.*;

class GameEventHandler2 extends MouseAdapter {
  public void mouseClicked(MouseEvent e) {
    GameBoard board = (GameBoard)e.getSource();
    int row = e.getY() / board.getCellHeight();
    int col = e.getX() / board.getCellWidth();
    if (board.getCell(row, col) == board.STATE0)
      board.setCell(row, col, board.STATE1);
    else
      board.setCell(row, col, board.STATE0);
    board.repaint();
  }
}
