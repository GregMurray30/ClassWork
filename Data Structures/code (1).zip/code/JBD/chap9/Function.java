//Function.java
interface Function {
  public double valueAt(double x);
}
