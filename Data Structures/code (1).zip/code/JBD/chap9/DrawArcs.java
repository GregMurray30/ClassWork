//DrawArcs.java -
import java.awt.*;
import javax.swing.*;

class DrawArcs extends JComponent
{
  public void paint(Graphics g) {
    g.drawArc(0, 0, 100, 60, 0, 160);
    g.fillArc(110, 0, 60, 60, 45, -135);
  }
  public Dimension getMinimumSize()
  { return dim;
  }
  public Dimension getPreferredSize()
  { return dim;
  }
  private Dimension dim = new Dimension(500,70); 
}
