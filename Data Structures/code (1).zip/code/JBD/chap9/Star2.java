//Star2.java - draws a resizable star burst
import java.awt.*;
import javax.swing.*;

class Star2 extends JComponent {

  public void paint(Graphics g) {
    for (double angle = 0; angle < Math.PI; 
        angle = angle + Math.PI / 16) {
      double x1, x2, y1, y2;
      // compute coordinates of endpoints of a line
      // cosine and sine range from -1 to 1
      // multiplying by RADIUIS gives changes the
      // range to be from -radius to radius
      // adding radius gives the final range of
      // 0 to 2 * radius
      x1 = Math.cos(angle) * radius + radius;
      y1 = Math.sin(angle) * radius + radius;
      x2 = Math.cos(angle + Math.PI) * radius +radius;
      y2 = Math.sin(angle + Math.PI) * radius +radius;
      g.drawLine((int)x1, (int)y1, (int)x2, (int)y2);
    }
  }
  public void setBounds(int x, int y,
                        int width, int height)
  {
    radius = Math.min(width, height) / 2;
    super.setBounds(x, y, width, height);
    repaint();
  }
  // make the Canvas just big enough to show the image
  public Dimension getMinimumSize() {
    return new Dimension(2 * radius, 2 * radius);
  }

  public Dimension getPreferredSize() {
    return new Dimension(2 * radius, 2 * radius);
  }

  private int radius = 100;
}
