//DrawingRectangles.java
import java.awt.*;
import javax.swing.*;

class DrawingRectangles
{
  public static void main(String[] args)
  {
    JFrame frame = new JFrame("DrawingRectangles");
    Container pane = frame.getContentPane();
    pane.add(new DrawRectangles());
    frame.pack();
    frame.show();
  }
}
