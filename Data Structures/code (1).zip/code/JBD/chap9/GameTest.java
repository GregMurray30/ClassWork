//GameTest.java
import java.awt.*;

class GameTest {
  public static void main(String[] args)
  {
    byte[][] state = new byte[20][20];

    Frame display = new Frame("GameTest");
    GameBoard board = new GameBoard(400, 400, state);
    GameEventHandler actor = new GameEventHandler();
    board.addMouseListener(actor);
    display.add(board, BorderLayout.CENTER);
    Button quit = new Button("Quit");
    quit.addActionListener(new GoodBye());
    display.add(quit, BorderLayout.NORTH);
    display.pack();
    display.show();
  }
}
