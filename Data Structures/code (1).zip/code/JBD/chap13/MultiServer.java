//MultiServer.java - a multithreaded server
import java.io.*;
import java.net.*;

class MultiServer {
  public static void main (String args[])
        throws java.io.IOException
  {
    if (args.length != 1) {
      System.out.println("Usage: " +
          "java MiniServer portnumber");
      System.exit(1);
    }
    int portnum = Integer.parseInt(args[0]);
        
    ServerSocket sock = null;
    try {
      sock = new ServerSocket(portnum);
    } 
    catch (IOException e) {
      System.out.println("Could not listen on port: "
                          + portnum + ", " + e);
      System.exit(1);
    }
    // above omitted in text - same as MiniServer
    System.out.println(
            "Now listening at port " + portnum);
    Socket clientSocket = null;
    while (true) {
      try {
        clientSocket = sock.accept();
      } 
      catch (IOException e) {
        System.out.println("Accept failed: "
                           + portnum + ", " + e);
        System.exit(1);
      }
      WorkerThread worker = 
                     new WorkerThread(clientSocket);
      worker.start();
    }
  }
}
