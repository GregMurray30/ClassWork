class Counter {
  Counter(int v, int mod) {
    value = v;
    modulus = mod;
  }
  int modulus; // max value is modulus - 1
  int value;                      //0 to modulus-1

  void reset() { value = 0; }

  int get()    { return value;}   //current value

  void click() { value = (value + 1) % modulus;}
}
