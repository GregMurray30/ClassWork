//GoodBye.java
import java.awt.event.*; 

class GoodBye implements ActionListener  { 
  public void actionPerformed(ActionEvent e) {
    System.out.println("Goodbye!"); 
    System.exit(0); 
  }
}
