//ClickCounter.java - count button clicks
import java.awt.event.*;

class ClickCounter implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    count++;
    System.out.println("Total clicks is " + count);
  }
  int count = 0;
}
