//MiniServer.java - server that echos what it receives
import java.io.*;
import java.net.*;

class MiniServer{
  public static void main (String args[])
        throws java.io.IOException
  {
    if (args.length != 1) {
      System.out.println("Usage: " +
          "java MiniServer portnumber");
      System.exit(1);
    }
    int portnum = Integer.parseInt(args[0]);
        
    ServerSocket sock = null;
    try {
      sock = new ServerSocket(portnum);
    } 
    catch (IOException e) {
      System.out.println("Could not listen on port: "
                          + portnum + ", " + e);
      System.exit(1);
    }
    System.out.println("Now listening at port " +
                        portnum);
        
    Socket clientSocket = null;
    try {
      clientSocket = sock.accept();
    }
    catch (IOException e) {
      System.out.println("Accept failed: " + 
                                portnum + ", " + e);
      System.exit(1);
    }
    BufferedReader input = new BufferedReader(
        new InputStreamReader(
          clientSocket.getInputStream()));
    PrintWriter output = 
      new PrintWriter(clientSocket.getOutputStream());
    System.out.println("Connection established.");
        
    int i = 0;
    String line = input.readLine();
    while (line!=null) {
      System.out.println(line);
      i++;
      output.println("line " + i + ":" + line);
      output.flush();
      line = input.readLine();
    }
  }
}
