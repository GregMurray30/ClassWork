//WorkerThread.java - handle one connection
import java.io.*;
import java.net.*;

class WorkerThread extends Thread {
  WorkerThread(Socket socket)
  {
    clientSocket = socket;
    workerNumber++;
    number = workerNumber;
  }
  public void run()
  {
    try {
      BufferedReader input = new BufferedReader(
          new InputStreamReader(
                    clientSocket.getInputStream()));
      PrintWriter output = new PrintWriter(
                    clientSocket.getOutputStream());
      System.out.println("Connection " +
                          number + " established.");
        
      String line = input.readLine();
      while (line != null) {
        System.out.println(line);
        output.println("worker " + number + ":"+line);
        output.flush();
        line = input.readLine();
      }
    }
    catch (IOException e) {
      System.out.println( e );
    }
    System.out.println("worker " + number+" exiting");
  }
  private Socket clientSocket;
  private static int workerNumber = 0;
  private int number;
}
