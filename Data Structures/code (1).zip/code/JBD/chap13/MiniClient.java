//MiniClient.java - simple client for MiniServer
import java.io.*;
import java.net.*;
import tio.*;

class MiniClient{
  public static void main (String args[])
         throws java.io.IOException
  {
    if (args.length != 2) {
      System.out.println("Usage: " +
          "java MiniClient hostname portnumber");
      System.exit(0);
    }
    int portnum = Integer.valueOf(args[1]).intValue();
    Socket sock = new Socket(args[0], portnum);
    BufferedReader input = new BufferedReader(
      new InputStreamReader(sock.getInputStream()));
    PrintWriter output = 
      new PrintWriter(sock.getOutputStream());
    System.out.println("Connection established.");
    System.out.println("type some characters then" +
        " return:");
    String line = Console.in.readLine();
    while (line != null) {
      output.println(line);
      output.flush();
      line = input.readLine();
      System.out.println("got back:" + line);
      System.out.println("type some characters " +
          "then return:");
      line = Console.in.readLine();
    }
  }
}
