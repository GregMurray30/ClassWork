//Buffer.java - a synchronized shared buffer
class Buffer {
  synchronized void put(int newValue) {
    while (!empty)
      try {
        //wait for previous value to be consumed
        wait();
      }
      catch(InterruptedException e) {
        System.out.println("wait interrupted: " + e);
      }
    value = newValue;
    empty = false;
    notify();
  }
  synchronized int get() {
    while (empty)
      try {
        wait(); // wait for buffer to fill
      }
      catch(InterruptedException e) {
        System.out.println("wait interrupted: "+e);
      }
    empty = true;
    notify();
    return value;
  }
  private boolean empty = true;
  private int value;
}
