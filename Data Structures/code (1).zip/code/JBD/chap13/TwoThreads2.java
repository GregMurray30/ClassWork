//TwoThreads2.java - two threads sharing a counter
class TwoThreads2 {
  public static void main(String[] args) {
    Counter counter = new Counter(0, 1000000);
    Racer t1 = new Racer(1, counter);
    Racer t2 = new Racer(2, counter);
    t1.start();
    t2.start();
  }
}
