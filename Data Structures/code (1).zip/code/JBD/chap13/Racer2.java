//Racer2.java - assume click() is not synchronized
class Racer2 extends Thread {
  Racer2(int id, Counter counter) {
    this.id = id;
    this.counter = counter;
  }
  public void run() {
    System.out.println("Thread" + id + " started.");
    for (int i = 0; i <  1000000; i++) {
      synchronized(counter) {
        counter.click();
      }
    }
    System.out.println("Thread" + id + 
            " finished counter is " + counter.get());
  }
  private int id;
  private Counter counter;
}
