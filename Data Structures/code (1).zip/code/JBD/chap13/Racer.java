//Racer.java - click the counter 100000 times
class Racer extends Thread {
  Racer(int id, Counter counter) {
    this.id = id;
    this.counter = counter;
  }
  public void run() {
    System.out.println("Thread" + id + " started.");
    for (int i = 0; i < 1000000; i++) {
      counter.click();
    }
    System.out.println("Thread" + id + 
            " finished counter is " + counter.get());
  }
  private int id;
  private Counter counter;
}
