//SimpleThread.java - periodically print a message
class SimpleThread extends Thread {

  SimpleThread(int threadId, int threadDelay) {
    id = threadId;
    delay = threadDelay; // in milliseconds
  }
  public void run() {
    System.out.println("Thread" + id + " started.");
    System.out.flush(); //needed to see the effect
    for (int i = 0; i < 10; i++) {
      try {
        sleep(delay); // sleep delay milliseconds
      }
      catch (InterruptedException e) {
        System.out.println("sleep interrupted: "+e);
      }
      System.out.println("Thread" + id + ": i = " +i);
    }
    System.out.println("Thread" + id + " finished.");
  }
  private int id;
  private int delay;
}
