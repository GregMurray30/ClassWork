//AwtThread.java - doing two things at once
import java.awt.*;
import javax.swing.*;
import tio.*;

class AwtThread {
  public static void main(String[] args)
       throws InterruptedException
  {
    createGUI();
    int count = 0;
    while (true) {
      count++;
      // go to sleep for 1 second = 1000 milliseconds
      Thread.currentThread().sleep(1000);
      System.out.println("count is now " + count);
      System.out.flush(); // force output to print now
    }
  }
  static void createGUI() {
    JFrame frame = new JFrame("AwtThread");
    Container pane = frame.getContentPane();
    JButton quit = new JButton("Quit");
    quit.addActionListener(new GoodBye());
    pane.add(quit, BorderLayout.NORTH);
    JButton counter = new JButton("Click to count");
    counter.addActionListener(new ClickCounter());
    pane.add(counter, BorderLayout.SOUTH);
    frame.pack();
    frame.show();
  }
}
