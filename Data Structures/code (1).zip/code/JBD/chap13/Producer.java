//Producer.java - "produce" the integers 0-9
class Producer extends Thread {
  Producer(Buffer buf) {
    buffer = buf;
  }
  public void run() {
    System.out.println("Producer started.");
    for (int i = 0; i <  10; i++) {
      // code to produce a value here
      System.out.println("Producer produced " + i);
      buffer.put(i); // let i be the produced value
    }
    System.out.println("Producer is finished.");
  }
  private Buffer buffer;
}
