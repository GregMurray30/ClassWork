//TwoThreads.java - create two simple threads
class TwoThreads{
  public static void main(String[] args) {
    SimpleThread t1 = new SimpleThread(1, 1000);
    SimpleThread t2 = new SimpleThread(2, 1300);
    t1.start();
    t2.start();
  }
}
