//CardTest.java testing the shuffling method.
public class CardTest {
  public static void main(String argv[]) {
    Deck deck = new Deck();
    System.out.println("\nNew Shuffle\n" + deck);
    deck.shuffle();
    System.out.println("\nNew Shuffle\n" + deck);
    deck.shuffle();
    System.out.println("\nNew Shuffle\n" + deck);
  }
}
