//Card.java - a playing card
class Card {
  Suit suit;   
  Pips pip;   
  Card(Suit s, Pips p) { suit = s; pip =p; }
  Card(Card c) { suit = c.suit; pip = c.pip; } 
  public  String toString() {
    return pip.toString() +":" 
        +  suit.toString()+ " ";  
  }   
}
