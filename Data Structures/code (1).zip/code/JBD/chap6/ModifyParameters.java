// ModifyParameters.java - you can't modify the actual
//     arg even when it is a reference

class ModifyParameters {
  public static void main(String[] args) {
    StringBuffer sbuf = new StringBuffer("testing");

    System.out.println("sbuf is now " + sbuf);
    modify(sbuf);
    System.out.println("sbuf is now " + sbuf);
  }
  static void modify(StringBuffer sb) {
    sb = new StringBuffer("doesn't work");
  }
}
