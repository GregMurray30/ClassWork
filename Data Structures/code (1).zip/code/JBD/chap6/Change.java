//Change.java

class Change {
  private int dollars, quarters, dimes, pennies;
  private double total;
  Change(int dlrs, int qtr, int dm, int pen) {
    dollars = dlrs;
    quarters = qtr;
    dimes = dm;
    pennies = pen;
    total = dlrs + 0.25 * qtr + 0.1 * dm + 0.01 * pen;
  }
  static Change makeChange(double paid, double owed) {
    double diff = paid - owed;
    int dollars, quarters, dimes, pennies;

    dollars = (int)diff;
    pennies = (int)((diff - dollars) * 100);
    quarters = pennies / 25;
    pennies -= 25 * quarters;
    dimes = pennies / 10;
    pennies -= 10 * dimes;
    return 
        new Change(dollars, quarters, dimes, pennies);
  }
  public String toString() {
    return ("$" + total + "\n" 
            + dollars + " dollars\n"
            + quarters + " quarters\n"
            + dimes + " dimes\n"
            + pennies + " pennies\n");
  }

public Change add(Change addend) {
  Change result = new Change(dollars + addend.dollars,
                  quarters + addend.quarters,
                  dimes + addend.dimes,
                  pennies + addend.pennies);

  return result;
}
}
