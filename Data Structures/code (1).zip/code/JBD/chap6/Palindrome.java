// Palindrome.java - check if a string is a palindrome
public class Palindrome {
  public static void main(String[] args) {
    String  str1 = "eye", str2 = "bye";
    System.out.println("Palindrome detection");
    System.out.println(str1 + " "
                        + isPalindrome(str1));
     System.out.println(str2 + " "
                        + isPalindrome(str2));
  }
  static boolean isPalindrome(String s) {
    int left = 0;
    int right = s.length() - 1;
    while (left < right) {
      if (s.charAt(left) != s.charAt(right))
        return false;
      left++;
      right--;
    }
    return true;
  }
}
