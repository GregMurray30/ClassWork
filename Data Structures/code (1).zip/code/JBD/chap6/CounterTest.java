// CounterTest.java - demonstration of class Counter
class CounterTest {
  public static void main(String[] args) {
    Counter c1 = new Counter(); //create a Counter
    Counter c2 = new Counter(); //create another

    c1.click();  // increment Counter c1
    c2.click();  // increment Counter c2
    c2.click();  // increment Counter c2 again
    System.out.println("Counter1 value is " +
                         c1.get());
    System.out.println("Counter2 value is " +
                         c2.get());
    c1.reset();
    System.out.println("Counter1 value is " +
                         c1.get());
  }
}
