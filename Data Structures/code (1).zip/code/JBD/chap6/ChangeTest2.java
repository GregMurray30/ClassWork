public class ChangeTest2 {
  public static void main(String[] args) {
    Change c1 = new Change(10, 3, 4, 3);
    Change c2 = new Change(7, 2, 2, 1);
    Change sum = c1.add(c2);

    System.out.println(sum);
  }
}
