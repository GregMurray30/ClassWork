/* <applet code="ButtonApplet.class"
    width=420 height=100></applet> */
//ButtonApplet.java - using buttons
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class ButtonApplet extends JApplet
    implements ActionListener {
  JButton buttonOne = new JButton("Button One");
  JButton buttonTwo = new JButton("Button Two");
  JTextField output = new JTextField(20);
  public void init() {
    Container pane = getContentPane();

    pane.setLayout(new FlowLayout());
    pane.add(buttonOne);
    pane.add(buttonTwo);
    pane.add(output);
    buttonOne.addActionListener(this);
    buttonTwo.addActionListener(this);
  }
  public void actionPerformed(ActionEvent e) {

    String cmd = e.getActionCommand();
    output.setText(cmd);
  }
}
