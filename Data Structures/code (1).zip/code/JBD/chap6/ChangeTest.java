public class ChangeTest {
  public static void main(String[] args) {
    double owed = 12.37;
    double paid = 15.0;
    System.out.println("You owe " + owed);
    System.out.println("You gave me " + paid);
    System.out.println("Your change is " +
                Change.makeChange(15.0, 12.37));
  }
}
