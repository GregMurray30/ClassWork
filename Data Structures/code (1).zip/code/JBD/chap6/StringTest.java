// StringTest.java - demo some String methods
public class StringTest {
  public static void main(String[] args) {
     String str1 = "aBcD", str2 = "abcd", str3;

     System.out.println(str1.equals(str2));
     System.out.println(str1.length());
     System.out.println(str1.charAt(1));
     System.out.println(str1.compareTo("aBcE"));
     System.out.println(str1.compareTo("aBcC"));
     System.out.println(str1.compareTo("aBcD"));
     System.out.println(str1.indexOf('D'));
     System.out.println(str1.indexOf("Bc"));
     System.out.println(str1.indexOf("zz"));
     System.out.println(str1.concat("efg"));
     str3 = str1.toLowerCase();
     System.out.println(str3);
     str3 = str1.toUpperCase();
     System.out.println(str3);
     System.out.println(str1);
     str3 = String.valueOf(123);
     System.out.println(str3.equals("123"));
  }
}
