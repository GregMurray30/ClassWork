class Counter {
  int value;                      //0 to 99

  void reset() { value = 0; }

  int get()    { return value;}   //current value

  void click() { value = (value + 1) % 100;}
}
