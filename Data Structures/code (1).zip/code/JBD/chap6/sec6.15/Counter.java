public class Counter {

  //public members - the interface to the class first
  //constants first then constructors then methods
  //overloaded methods are together
  public static final int MODULUS = 100;
  public Counter() { howMany++; }
  public Counter(int v) {
    value = v % MODULUS;
    howMany++;
  }
//methods are alphabetical
  public void click() {value = (value + 1) % MODULUS;}
  public int get()    { return value;}
  public static int howMany() { return howMany; }
  public void reset() { value = 0; }

//private members - implementation
  private int value;
  private static int howMany = 0;
}
