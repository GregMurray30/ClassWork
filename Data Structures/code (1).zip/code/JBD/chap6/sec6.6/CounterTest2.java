// CounterTest2.java - demonstration of static field
class CounterTest2 {
  public static void main(String[] args) {
    System.out.println(Counter.howMany());
    Counter c1 = new Counter();
    Counter c2 = new Counter();
    c1.click();
    c2.click();
    c2.click();
    System.out.println("Counter1 value is " +
          c1.get()); //prints Counter1 value is 1
    System.out.println("Counter2 value is " +
          c2.get()); //prints Counter2 value is 2
    System.out.println(Counter.howMany());// prints 2
  }
}
