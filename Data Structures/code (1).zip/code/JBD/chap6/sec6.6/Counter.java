public class Counter {
  //instance variables -fields -- hidden
  private int value;
  private static int howMany = 0;
  //methods -- exposed
  public Counter(){ howMany++; }
  public void reset() { value = 0; }
  public int get()    { return value; }
  public void click() { value = (value + 1) % 100; }
  public static int howMany() { return howMany; }
}
