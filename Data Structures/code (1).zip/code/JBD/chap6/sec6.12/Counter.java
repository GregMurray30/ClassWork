class Counter {
  int value;                      //0 to MDOULUS-1

  void reset() { value = 0; }
  int get()    { return value;}   //current value
  void click() { value = (value + 1) % MODULUS; }

  private static final int MODULUS = 100;
}
