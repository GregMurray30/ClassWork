// PassingReferences.java - object parameters can be
//                          modified

class PassingReferences {
  public static void main(String[] args) {
    StringBuffer sbuf = new StringBuffer("testing");

    System.out.println("sbuf is now " + sbuf);
    modify(sbuf);
    System.out.println("sbuf is now " + sbuf);
  }
  static void modify(StringBuffer sb) {
    sb.append(", 1 2 3");
  }
}
