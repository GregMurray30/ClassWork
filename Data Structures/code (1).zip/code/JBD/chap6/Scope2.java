//Scope2.java: class versus local scope
class Scope2  { 
  public static void main(String[] args) {
    int x = 2;

    System.out.println("local x = "+x);
    System.out.println("class variable x = "
                       + Scope2.x);
  }
  static int x = 1;
}
