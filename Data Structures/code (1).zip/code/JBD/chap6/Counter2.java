// Counter.java - a simple wrap around counter
public class Counter2 {
  //instance variables -fields -- hidden
   private int value;

  //methods -- exposed
  public void reset() { value = 0; }

  public int get()    { return value;}

  public void click() {value = (value + 1) % 100;}
}
