//Grass.java - something for the rabbits to eat
class Grass extends Living {
  public Grass(int r, int c) { row = r; column = c; }
  public Living next(World world) {
    computeNeighbors(world);
    if (Grass.neighborCount.get() >
        2 * Rabbit.neighborCount.get())
      // rabbits move in to eat the grass
      return (new Rabbit(row, column, 0));
    else if (Grass.neighborCount.get() >
             Rabbit.neighborCount.get())
      // grass remains
      return (new Grass(row, column));
    else
      // rabbits eat all the grass
      return (new Empty(row, column));
  }
  public String toString() { return "Grass"; }
  char toChar() { return 'G'; }
  Count getCount() { return neighborCount; }
  static Count neighborCount = new Count();
}
