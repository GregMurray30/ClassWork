//PredatorPrey.java - top level class
class PredatorPrey {
  public static void main(String[] args) {
    World odd = new World(10), even = new World(10);
    int i, cycles = 10;
    even.eden();              //generate initial World
    System.out.println(even); //print initial state
    for (i = 0; i < cycles; i++) {
      System.out.println("Cycle = " + i + "\n\n");
      if (i % 2 == 1) {
        even.update(odd);
        System.out.println(even);
      }
      else {
        odd.update(even);
        System.out.println(odd);
      }
    }
  }
}
