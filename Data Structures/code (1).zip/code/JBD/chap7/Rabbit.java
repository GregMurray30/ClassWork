//Rabbit.java - prey class
class Rabbit extends Living {
  Rabbit(int r, int c, int a ) 
    { row = r; column = c; age = a;}
  Living next(World world) {
    computeNeighbors(world);
    if (Fox.neighborCount.get() >=
       Rabbit.neighborCount.get() )
      return (new Empty(row, column));  // eat Rabbits
    else if (age > LIFE_EXPECTANCY)
      return (new Empty(row, column));  // too old
    else if (Grass.neighborCount.get() == 0)
      return (new Empty(row, column));  // starved
    else
      return (new Rabbit(row, column, age + 1));
  }
  public String toString() {return "Rabbit age "+age;}
  char toChar() { return 'R'; }
  Count getCount() { return neighborCount; }

  static Count neighborCount = new Count();
  private int age;
  private final int LIFE_EXPECTANCY = 3;
}
