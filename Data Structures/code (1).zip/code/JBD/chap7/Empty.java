//Empty.java - representation of an empty cell
class Empty extends Living {
  Empty(int r, int c) { row = r; column = c; }
  Living next(World world) {
    computeNeighbors(world);
    if (Rabbit.neighborCount.get() > 2)
      return (new Fox(row, column, 0));
    else if (Grass.neighborCount.get() > 4)
      return (new Rabbit(row, column, 0));
    else if (Grass.neighborCount.get() > 0)
      return (new Grass(row, column));
    else
      return (new Empty(row, column));
  }
  public String toString() { return "."; }
  char toChar() { return '.'; }
  Count getCount() {  return neighborCount; }
  static Count neighborCount = new Count();
}
