public class Counter extends AbstractCounter {
  public void click() { value = (value + 1) % 100; }
}
