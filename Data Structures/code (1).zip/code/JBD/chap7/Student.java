//Student.java - an example subclass
class Student extends Person  {
  Student(String name) {  super(name); }
  void setCollege(String college)
      { this.college = college; }
  void setGpa(double gpa)   { this.gpa = gpa; }
  void setYear(byte year)   { this.year = year; }
  String getCollege()       { return college; }
  double getGpa()           { return gpa; }
  byte getYear()            { return year; }
  public String toString() {
    return(super.toString() + "\n  " +
      "College: " + college +
      ", GPA: " + gpa +
      ", Year: " + year);
  }
  static final byte FROSH = 1;
  static final byte SOPH = 2;
  static final byte JUNIOR = 3;
  static final byte SENIOR = 4;
  private String college = "Unknown";
  private byte year; // FROSH, SOPH, ...
  private double gpa; //0.0 to 4.0
}
