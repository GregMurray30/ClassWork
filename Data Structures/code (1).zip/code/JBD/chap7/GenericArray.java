// GenericArray.java - 
//     demonstrate generic array container
class GenericArray {
  public static void main(String[] args) {
    Object[] array = new Object[4];

    array[0] = "String 1";
    array[1] = new Integer(1);
    array[2] = "String 2";
    array[3] = new Integer(2);
    for (int i = 0; i < array.length; i++) {
      if (array[i] instanceof String) {
        String temp = (String)array[i];
        System.out.println("Processing string "
            + temp);
        // do something appropriate for strings
      }
      else if (array[i] instanceof Integer) {
        Integer temp = (Integer)array[i];
        System.out.println("Processing Integer " 
            + temp);
        // do something appropriate for an Integer
      }
      else {
        System.out.println("Unexpected type " 
            + array[i]);
        // do something to handle unexpected cases
      }
    } // end of for loop
  }
}
