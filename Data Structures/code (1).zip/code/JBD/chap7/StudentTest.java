//StudentTest.java
class StudentTest {
  public static void main(String[] args) {
    Student student = new Student("Jane Programmer");

    student.setAge(21);
    student.setGender('F');
    student.setCollege("UCSC");
    student.setYear(Student.FROSH);
    student.setGpa(3.75f);
    System.out.println(student.toString());
  }
}
