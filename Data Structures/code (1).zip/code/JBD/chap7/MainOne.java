class MainOne {
  public static void main(String[] args) {
    ClassOne one = new ClassOne();
    ClassTwo two;

    one.print();
    one = new ClassTwo();
    one.print();
    two = (ClassTwo)one;
    two.print();
  }
}
