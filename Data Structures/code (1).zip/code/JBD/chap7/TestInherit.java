//TestInherit.java - overridden method selection.
class TestInherit {
  public static void main(String[] args) {
     SuperClass s =  new SuperClass();
    s.print();
    s = new SubClass();
    s.print();
  }
}
