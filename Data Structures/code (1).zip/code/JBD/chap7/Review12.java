class Review12 {
  public static void main(String[] args) {
    ClassOne one = new ClassOne();

    one.print();
    ClassTwo two = (ClassTwo)one;
    two.print();
  }
}
