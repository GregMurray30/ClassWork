//SubClass.java - a subclass of SuperClass
class SubClass extends SuperClass {
  public void print() {
    System.out.println( " inside SubClass");
  } 
}
