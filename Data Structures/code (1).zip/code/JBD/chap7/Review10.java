public class Review10 {
  public static void main(String[] args) {
    Integer m = new Integer(3), n = new Integer(3);
    System.out.println(m);
    System.out.println(m.equals(n)+ " : " +
                         (m == n));
  }
}
