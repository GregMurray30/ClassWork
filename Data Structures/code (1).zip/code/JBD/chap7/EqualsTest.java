//EqualsTest.java -
class EqualsTest {
  public static void main(String[] args) {
    // Create and fill an array of Strings
    String[] stringArray = new String[10];

    for (int i = 0; i < stringArray.length; i++)
      stringArray[i] = "String " + i;
    // Create and fill an array of Counters
    Counter[] counterArray = new Counter[5];

    for (int i = 0; i < counterArray.length; i++)
      counterArray[i] = new Counter();
    // Make two entries refer to the same Counter
    counterArray[2] = counterArray[0];
    System.out.println(
      howManyCopiesOf(counterArray[0], counterArray));
    System.out.println(
      howManyCopiesOf("String 1", stringArray));
  }
  //Count the number of times obj is found in array.
  static int howManyCopiesOf(Object obj, 
                             Object[] array) {
    int  count = 0;

    for (int i = 0; i < array.length; i++)
       if (obj.equals(array[i]))
           count++;
    return count;
  }
}
