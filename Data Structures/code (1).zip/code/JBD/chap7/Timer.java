class Timer extends AbstractCounter {

  public Timer(int v) { set(v); }
  public void click() {
    value++;
    seconds = value % 60;
    minutes = value / 60;
  }
  public void set(int v) {
    value = v;
    seconds = v % 60;
    minutes = v / 60;
  }
  public String toString() {
    return minutes + " minutes, " +
           seconds + " seconds";
  }
  private int seconds, minutes;
}
