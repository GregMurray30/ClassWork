//SuperClass.java - a sample super class
class SuperClass { 
  public void print() { 
    System.out.println( " inside SuperClass");
  } 
}
