interface Living {
  Living next(World world);
  char toChar();
  void computeNeighbors(World world);
  Count getCount();
}
