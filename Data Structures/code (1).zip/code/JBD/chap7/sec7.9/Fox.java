//Fox.java - prey class
class Fox implements Living {
  Fox(int r, int c, int a ) 
    { row = r; column = c; age = a; }
  public Living next(World world) {
    computeNeighbors(world);
    if (Fox.neighborCount.get() > 5 ) //too many Foxes
      return new Empty(row, column);
    else if (age > LIFE_EXPECTANCY)   //Fox is too old
      return new Empty(row, column);
    else if (Rabbit.neighborCount.get() == 0)
      return new Empty(row, column);  // starved
    else
      return new Fox(row, column, age + 1);
  }
  public String toString(){ return "Fox age " + age; }
  public char toChar() { return 'F'; }
  public Count getCount() {  return neighborCount; }
  static Count neighborCount = new Count();

  private int age;
  private final int LIFE_EXPECTANCY = 5;



  public void computeNeighbors(World world) { 
    world.clearNeighborCounts();
    world.cells[row][column].getCount().set(-1);
    for (int i = -2; i <= 2; i++)
      for (int j = -2; j <= 2; j++)
        if (row + i > 0 && 
           row + i < world.cells.length &&
           column + j > 0 && 
           column + j < world.cells[0].length)
        {
          world.cells[row + i][column + j]
                               .getCount().inc();
        }
  }

  // an interface doesn't contain data fields
  // so row and column must be declared here
  // we can now make these members private
  private int row, column;
}
