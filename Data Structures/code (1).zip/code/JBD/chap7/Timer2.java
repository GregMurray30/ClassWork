// modification of Timer
class Timer2 extends AbstractCounter {
  public Timer2(int v) { set(v); }
  public void click() { value++; }

  public String toString() {
    return (value / 60) + " minutes, " +
           (value % 60) + " seconds";
  }
}
