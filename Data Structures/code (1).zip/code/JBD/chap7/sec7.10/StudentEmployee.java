import java.util.Date;

class StudentEmployee implements Student, Staff {
  // methods required by Person
  public void setAge(int age){ }
  public void setGender(char gender){ }
  public void setName(String name){ }
  public int getAge(){return 0;}
  public char getGender(){return 'f';}
  public String getName(){return "";}
  // methods required by Student
  public void setCollege(String college){ }
  public void setGpa(double gpa){ }
  public void setYear(byte year){ }
  public String getCollege(){return "";}
  public double getGpa(){return 0;}
  public byte getYear(){return (byte)0;}
  // methods required by Staff
  public void setSalary(double salary){ }
  public void setStartDate(Date start){ }
  public void setEndDate(Date end){ }
  public void setSSN(String ssn){ }
  public double getSalary(){return 0;}
  public Date getStartDate(){return null;}
  public Date getEndDate(){return null;}
  public String getSSN(){return "";}
}
