interface Student extends Person {
  void setCollege(String college);
  void setGpa(double gpa);
  void setYear(byte year);
  String getCollege();
  double getGpa();
  byte getYear();
  static final byte FROSH = 1;
  static final byte SOPH = 2;
  static final byte JUNIOR = 3;
  static final byte SENIOR = 4;
}
