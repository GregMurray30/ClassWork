interface Person {
  void setAge(int age);
  void setGender(char gender);
  void setName(String name);
  int getAge();
  char getGender();
  String getName();
}
