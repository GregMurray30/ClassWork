import java.util.Date;

interface Staff extends Person {
  void setSalary(double salary);
  void setStartDate(Date start);
  void setEndDate(Date end);
  void setSSN(String ssn);
  double getSalary();
  Date getStartDate();
  Date getEndDate();
  String getSSN();
}
