public class CountByTwo extends AbstractCounter {
  public void click() { value = (value + 2) % 100; }
}
