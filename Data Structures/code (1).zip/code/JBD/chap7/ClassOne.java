class ClassOne {
  public void print() { 
    System.out.println( "ClassOne");
  } 
}
