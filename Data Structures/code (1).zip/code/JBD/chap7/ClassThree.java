class ClassThree extends ClassOne {
  public void print() {
    System.out.println( "ClassThree");
  } 
}
