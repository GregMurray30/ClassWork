//World.java - square grid of life form cells
class World {

  World(int n) {
    size = n; cells = new Living[n][n];
    for (int i = 0; i < size; i++)
      for (int j = 0; j < size; j++)
        cells[i][j] = new Empty(i,j);
  }
  public void clearNeighborCounts() {
    Fox.neighborCount.set(0);
    Rabbit.neighborCount.set(0);
    Grass.neighborCount.set(0);
    Empty.neighborCount.set(0);
  }
  public void eden()
  {
    // left as an excercise
  }
  public String toString()
  {
    // left as an excercise
  }
  public void update(World oldWorld) {
    //borders are taboo
    for (int i = 1; i < size - 1; i++) 
      for (int j = 1; j < size - 1; j++)
        cells[i][j] =
            oldWorld.cells[i][j].next(oldWorld);
  }
  Living[][]  cells;
  private int size;  //set in constructor
}
