class Review13 {
  public static void main(String[] args) {
    ClassThree three = new ClassThree();

    three.print();
    ClassTwo two = (ClassTwo)three;
    two.print();
  }
}
