//IteratorExample.java
class IteratorExample {
  static boolean checkDuplicate(IntList list) {
    // count the number of elements in the list
    int numElements=0;
    IntListIterator iterator = list.iterator();
    while (iterator.hasNext()) {
      iterator.next();
      numElements++;
    }
    // check for an even number of elements
    if (numElements%2 != 0)
      return false;
    // now compare the first half with the second half
    IntListIterator first = list.iterator();
    IntListIterator second = list.iterator();
    // advance second to the start of the second half
    for (int i = 1; i <= numElements / 2; i++)
      second.next();
    while (second.hasNext())
      if (first.next() != second.next())
        return false;
    return true;
  }
}
