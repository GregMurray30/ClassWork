//IntListIteratorTest.java
class IntListIteratorTest {
  public static void main(String[] args) {
    IntList list = new IntList();
    // insert the integers 10 through 1 in the list
    for (int i=1; i<=10; i++)
      list.insert(11 - i);
    // print the list
    list.moveToHead();
    while (list.hasNext())
      System.out.println(list.next());
    list = IntListSort.sort(list);
    // print the list again
    list.moveToHead();
    while (list.hasNext())
      System.out.println(list.next());
  }
}
