// IntListIterator.java - simple forward iterator
class IntListIterator {
  // Create an iterator positioned before the first
  // element of the list.
  IntListIterator(IntList list) {
    current = null;
    this.list = list;
  }
  // Create an iterator positioned at element pos.
  IntListIterator(IntList list, IntListElement pos) {
    // pos must refer to an element in list
    current = pos;
    this.list = list;
  }
  //Same as next() in IntList.
  int next() {
    if (current == null)
      current = list.head;
    else
      current = current.next;
    return current.data;
  }
  //Same as hasNext() in IntList.
  boolean hasNext() {
    if (current != null) 
      return current.next != null;
    else
      return list.head != null;
  }
  int current() {
    return current.data;
  }
  IntListIterator copy() {
    return new IntListIterator(list,current);
  }
  IntListElement current;
  IntList list;
}
