//IntListTest.java
class IntListTest {
  public static void main(String[] args) {
    IntList list = new IntList();
    // insert the integers 1 through 10 in the list
    for (int i=1; i<=10; i++)
      list.insert(i);
    // print the list
    list.moveToHead();
    while (list.hasNext())
      System.out.println(list.next());
    // try an insertion and a deletion
    list.moveToHead();
    list.next();     // current is 1
    list.next();     // current is 2
    list.insert(25); // insert 25 between 2 and 3
    list.next();     // current is 3
    list.remove();    // remove 3
    // print the list again
    list.moveToHead();
    while (list.hasNext())
      System.out.println(list.next());
  }
}
