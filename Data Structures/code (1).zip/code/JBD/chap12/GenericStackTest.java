//GenericStackTest.java
class GenericStackTest {
  public static void main(String[] args) {
    Stack stack = new Stack();

    stack.push(new Double(1.111));
    stack.push(new Double(2.222));
    stack.push(new Double(3.333));
    while (!stack.empty()) {
      double temp =
                ((Double)stack.pop()).doubleValue();
      System.out.println(temp);
    }
  }
}
