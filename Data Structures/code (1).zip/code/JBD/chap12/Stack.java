//Stack.java - a generic stack
class Stack {
  Object top() {
    if (top != null)
      return top.data;
    else
      return null;
  }
  void push(Object value) {
      if (top == null) {
        top = new ListElement(value);
      }
      else {
        ListElement temp = new ListElement(value);
        temp.next = top;
        top = temp;
      }
  }
  Object pop() {  
    Object result = top();
    if (top != null)
      top = top.next;
    return result;
  }
  boolean empty() { return top == null; }
  private ListElement top = null;
}
