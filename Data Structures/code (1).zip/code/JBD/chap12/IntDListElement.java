//IntDListElement - for doubly linked lists
class IntDListElement {
  IntDListElement(int value) { data = value;}
  IntDListElement next;
  IntDListElement previous;
  int data;
}
