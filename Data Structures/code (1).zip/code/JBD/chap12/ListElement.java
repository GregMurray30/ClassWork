//ListElement.java - a generic list element
class ListElement {
  ListElement(Object value) {
    data = value;
  }
  ListElement next;
  Object data;
}
