// VectorTest.java - using Vector as a list
import java.util.*;

class VectorTest {
  public static void main(String[] args) {
    Vector list = new Vector();
    for (int i = 1; i <= 10; i++)
      list.addElement(new Integer(i));
    System.out.println(list);
    // insert 25 between 2 and 3
    list.insertElementAt(new Integer(25), 2);
    list.removeElementAt(3);
    System.out.println(list);
  }
}
