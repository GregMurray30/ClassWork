//QueueTest.java
class QueueTest {
  public static void main(String[] args) {
    Queue queue = new Queue();

    queue.add(new Double(1.111));
    queue.add(new Double(2.222));
    queue.add(new Double(3.333));
    while (!queue.empty()) {
      double temp =
              ((Double)queue.pop()).doubleValue();
      System.out.println(temp);
    }
  }
}
