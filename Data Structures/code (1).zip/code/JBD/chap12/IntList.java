//IntList.java - a linked list of integers

class IntList {
  private IntListElement head,current,previous;

void insert(int value) {
  previous = current;
  if (current != null) {
    IntListElement next = current.next;      //step 1
    current.next = new IntListElement(value);//step 2
    current = current.next;                  //step 3
    current.next = next;                     //step 4
  }
  else if (head != null) {
    current = new IntListElement(value);
    current.next = head;
    head = current;
  }
  else /* list is empty */
    head = current = new IntListElement(value);
}

int next() {
  previous = current;
  if (current == null)
    current = head;
  else
    current = current.next;
  return current.data;
}

int current() {
  return current.data;
}
void remove() {
  if (head == null) return;
  if (current == null) return;
  if (current == head)
    head = current = current.next;
  else
    current = previous.next = current.next;
}


void moveToHead() {
  previous = current = null;
}

boolean hasNext() {
  if (current != null) 
    return current.next != null;
  else
    return head != null;
}

}
