//Queue.java
class Queue {
  Object front() {
    if (head != null)
      return head.data;
    else
      return null;
  }
  void add(Object value) {
    if (head == null) {
      head = tail = new ListElement(value);
    }
    else {
      tail.next = new ListElement(value);
      tail = tail.next;
    }
  }
  Object pop() {  
    Object result = front();
    if (head != null)
      head = head.next;
    return result;
  }
  boolean empty() { return head == null; }
  private ListElement head = null;
  private ListElement tail = null;
}
