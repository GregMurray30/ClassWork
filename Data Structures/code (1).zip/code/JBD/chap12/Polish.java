//Polish.java - two stack Polish evaluation algorithm
class Polish {

  public static void main(String[] args) {
    String[] expression = 
             {"13", "4", "-", "2", "3", "*", "+"};
    Stack stack = new Stack();
    Stack intArguments = new Stack();
    String opval;

    for (int i = expression.length - 1; i >= 0; i--)
      stack.push(expression[i]);
    while (!stack.empty()) {
      opval = (String)stack.pop();
      if (!isOperator(opval))
        intArguments.push(opval);
      else
        intArguments.push(eval(opval, intArguments));
    }
    System.out.println(" = " + intArguments.top());
  }
  static boolean isOperator(String s) {
    return  s.equals("+") || 
            s.equals("*") || s.equals("-");
  }
  // apply a binary operator to the top two operands
  // on the stack
  static String eval(String operator, Stack stack) {
    String a, b;
    b = (String)stack.pop();
    a = (String)stack.pop();
    if (operator.equals("+")) 
      return  String.valueOf(Integer.parseInt(a) +
                             Integer.parseInt(b));
    else if (operator.equals("-"))
      return  String.valueOf(Integer.parseInt(a) -
                             Integer.parseInt(b));
    else
      return  String.valueOf(Integer.parseInt(a) * 
                             Integer.parseInt(b));
  }
}
