//IntStack.java - a stack implemented with a list
class IntStack {
  int top() {
    if (top != null)
      return top.data;
    else
      return 0;
  }
  void push(int value) {
      if (top == null) {
        top = new IntListElement(value);
      }
      else {
        IntListElement temp = 
                new IntListElement(value);
        temp.next = top;
        top = temp;
      }
  }
  int pop() {  
    int result = top();;
    if (top != null)
      top = top.next;
    return result;
  }
  boolean empty() { return top == null; }
  private IntListElement top = null;
}
