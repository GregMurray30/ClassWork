//UnambiguousOverload.java: no ambiguity here
class UnambiguousOverload {
  public static void main(String[] args) {
    int i = 1, j = 2;

    System.out.println(unAmbig(i,j));
  }
  static boolean unAmbig(float x, float y){
    return x < y;
  }
  static boolean unAmbig(double x, double y){
    return x < y;
  }
}
