//RandomPrint.java: Print Random numbers  in the
//    range (0.0 - 1.0).
class RandomPrint {
  public static void main(String[] args) {
    int n = 10;

    System.out.println("We will print " + n + 
       " random numbers");
    printRandomNumbers(n);
  }
  static void printRandomNumbers(int k) {
    for (int i = 0; i < k; i++)
      System.out.println(Math.random());
  }
}
