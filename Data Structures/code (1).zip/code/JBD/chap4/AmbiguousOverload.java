//AmbiguousOverload.java: won't compile
class AmbiguousOverload {
  public static void main(String[] args) {
    int i = 1, j = 2;

    System.out.println(ambig(i,j));
  }
  static boolean ambig(float x, int y){
    return x < y;
  }
  static boolean ambig(int x, float y){
    return x < y;
  }
}
