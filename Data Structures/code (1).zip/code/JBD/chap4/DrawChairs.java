/* <applet code="DrawChairs.class"
   width=150 height=120></applet> */
import java.awt.*;
import javax.swing.*;
public class DrawChairs extends JApplet {
  public void paint(Graphics g) {
    drawChair(10,10,50,100,g);
    drawChair(70,10,25,50,g);
    drawChair(105,10,10,20,g);
  }
  /**
   * drawChair draws a chair at the specified
   *    position, scaled to the specified size
   * @param left The distance in from the left edge.
   * @param top The distance down from the top.
   * @param width The width of the chair seat.
   * @param height The height of the chair back.
   * @param Graphics The object to draw on.
   */
  void drawChair(int left, int top,
                 int width, int height, Graphics g){
    // thickness of the legs, back and seat
    int thickness = width/10 + 1;

    // draw the seat
    g.fillRect(left, top + height / 2,
               width, thickness);
    // draw the back and back leg
    g.fillRect(left + width - thickness, top,
               thickness, height);
    // draw the front leg
    g.fillRect(left, top + height /2 ,
               thickness, height / 2);
  }
}
