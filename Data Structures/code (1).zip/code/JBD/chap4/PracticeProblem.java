class PracticeProblem {
  public static void main (String[] args) {
    int x = 10, y = 5;

    printProduct(x, y);
    x = 2;
    printProduct(x + y, x);
  }
  static void printProduct(int x,int y) {
    System.out.print("The Product of " + x);
    System.out.print(" and " + y + " is ");
    System.out.println(x * y);
  }
}
