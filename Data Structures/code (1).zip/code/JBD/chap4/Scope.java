class Scope {
  public static void main(String[] args) {
    int x = 1;

    {
      int x = 2;
      int y = 3;

      System.out.println("x = " + x);
      System.out.println("y = " + y);
    }
    System.out.println("x = " + x);
    System.out.println("y = " + y);
  }
}
