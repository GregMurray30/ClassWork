//FailedSwap.java - Call-By-Value test
class FailedSwap {
  public static void main(String[] args) {
    int numOne = 1, numTwo = 2;

    swap(numOne, numTwo);
    System.out.println("numOne = " + numOne);
    System.out.println("numTwo = " + numTwo);
  }
  static void swap(int x, int y) {
    int temp;

    System.out.println("x = " + x);
    System.out.println("y = " + y);
    temp = x;
    x = y;
    y = temp;
    System.out.println("x = " + x);
    System.out.println("y = " + y);
  }
}
