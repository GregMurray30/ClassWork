// Min2.java: return expression in a method

class Min2 {
  public static void main(String[] args) {
    int   j = 78, k = 3 * 30, m;
    System.out.println(
          "Minimum of two integers Test:");
    m = min(j, k);
    System.out.println("The minimum of : "
       + j + " , " + k + " is  " + m);
  }
  static int min(int a, int b) {
    if (a < b)
      return a;
    else
      return b;
  }
}
