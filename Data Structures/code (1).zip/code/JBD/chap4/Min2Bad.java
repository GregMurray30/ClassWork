// Min2Bad.java - doesn't work because of scope

class Min2Bad {
  public static void main(String[] args) {
    int   j = 78, k = 3 * 30, m;
    System.out.println(
         "Minimum of two integers Test:");
    m = min();
    System.out.println("The minimum of : "
         + j + " , " + k + " is  " + m);
  }
  static int min() {
    if (j < k)
      return j;
    else
      return k;
  }
}
