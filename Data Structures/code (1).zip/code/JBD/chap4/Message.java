// Message.java: Simple method use
class Message {
  public static void main(String[] args) {
    System.out.println("HELLO DEBRA!");
    printMessage(); //method call
    System.out.println("Goodbye.");
  }
  //definition of method printMessage
  static void printMessage() {
    System.out.println("A message for you:  ");
    System.out.println("Have a nice day!\n");
  }
}
