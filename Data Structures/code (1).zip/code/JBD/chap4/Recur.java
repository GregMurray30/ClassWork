// Recur.java - recursive goodbye
public class Recur {
  public static void main(String[] args) {
    sayGoodBye(5);
  }
  static void sayGoodBye(int n) {
    if (n < 1) //base case
      System.out.println("########");
    else     {
      System.out.println("Say goodbye Gracie.");
      sayGoodBye(n - 1); //recursion
    }
  }
}
