//RandomPrint.java: Print Random numbers  in the
//    range (0.0 - 1.0).
class RandomPrint2 {
  public static void main(String[] args) {
    int n = 10;

    System.out.println("We will print " + n + 
       " random numbers");
    printRandomNumbers(n);
  }
static void printRandomNumbers(int k) {
  double r, biggest, smallest;

  r = biggest = smallest = Math.random();
  System.out.print(" " + r);
  for (int i = 1; i < k; i++) {
    if (i % 2 == 0)
       System.out.println();
    r = Math.random();
    biggest = max(r, biggest);
    smallest = min(r, smallest);
    System.out.print(" " + r);
  }
  System.out.println("\nCount: " + k 
      + "  Maximum: " + biggest + "  Minimum: " 
      + smallest);
}
static double max(double a, double b) {
  if (a > b)
    return a;
  else
    return b;
}
  static double min(double a, double b) {
    if (a < b)
      return a;
    else
      return b;
  }
}
