//CoinToss.java - Compute the approximate probability
//    of n heads in a row by simulating coin tosses.

class CoinToss {
  public static void main(String[] args) {
    //Input the number of tosses in a row to try for.
    int numTosses = 4;      //Just use 4 for testing

    //Input the number of trials to run.
    int numTrials = 10000;  //Use 10000 for testing

    //Perform the specified number of trials
    int numSuccesses =
      performTrials(numTosses,numTrials);

    //Print the results
    double probability = 
      numSuccesses / (double)numTrials;
    System.out.println("Probability found in " 
           + numTrials + " is  " + probability);       
  }
  // return true if numTosses heads are tossed
  // before a tail
  static boolean isAllHeads(int numTosses) {
    double outcome;

    for (int numHeads = 0; numHeads < numTosses;
                           numHeads++) {
      outcome = Math.random();   // toss the coin
      if ( outcome < 0.5)
        return false;            // tossed a tail
    }
    return true;                 // tossed all heads
   }
  // perform numTrials simulated coin tosses
  // and return the number of successes
  static int performTrials(int numTosses,
                           int numTrials) {
    System.out.println("Monte Carlo " + numTosses + 
                       " in a row heads");
    int numSuccesses = 0;
    for (int trials= 0 ; trials < numTrials; trials++)
      // perform one trial
      if ( isAllHeads(numTosses))
        numSuccesses++;         // trial was a success
    return numSuccesses;
  }
}
