// SquareRoots2.java - contains scope errors
public class SquareRoots2 {
  public static void main(String[] args) {
    int i = 99;
    double squareRoot = Math.sqrt(i);

    System.out.println("the square root of " + i +
                         " is " + squareRoot);

    for (int i = 1; i <= 10; i++) {
      double squareRoot = Math.sqrt(i);
      double square = squareRoot * squareRoot;
      System.out.println("the square root of " + i +
                         " is " + squareRoot);
      System.out.println("squaring that yields " +
                          square);
    }
    System.out.println("The final value of square"
                       + " is " + square);
  }
}
