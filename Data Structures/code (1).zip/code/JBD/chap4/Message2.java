// Message2.java: method parameter use
class Message2 {
  public static void main(String[] args) {
    System.out.println("HELLO DEBRA!");
    printMessage(5); //actual argument is 5
    System.out.println("Goodbye.");
  }
  static void printMessage(int howManyTimes) {
  //formal parameter  is howManyTimes
    System.out.println("A message for you:  ");
      for (int i = 0; i < howManyTimes; i++)
        System.out.println("Have a nice day!\n");
  }
}
