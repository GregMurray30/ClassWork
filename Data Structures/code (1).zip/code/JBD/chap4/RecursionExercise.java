class RecursionExercise {
  public static void main(String[] args) {
    for (int i = 0; i < 10; i++)
      System.out.println(recurse(i));
  }
  static long recurse(long n) {
    if (n <= 0)
      return 1;
    else
      return 2 * recurse(n - 1);
  }
}
