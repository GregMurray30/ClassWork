//RunSums.java: top level, main(), calls methods to
//    handle subproblems
import tio.*;
class RunSums {
  public static void main(String[] args) {
    printBanner();
    printHeadings();
    readAndPrintData();
  }
  // printBanner, printHeadings and readAndPrintData
  // definitions will go here

  static void printBanner() {
    System.out.println("\n" +
      "********************************************\n" +
      "*   RUNNING SUMS, MINIMUMS, AND MAXIMUMS   *\n" +
      "********************************************\n");
  }

  static void printHeadings() {
  System.out.println(
             "Count\tItem\tSum\tMinimum\tMaximum");
  }

  static void readAndPrintData() {
    int cnt = 0, sum = 0, item, smallest, biggest;

    item = Console.in.readInt();
    smallest = biggest = item;
    while (item != -99999) {
      cnt++;
      sum = sum + item;
      smallest = min(item, smallest);
      biggest = max(item, biggest);
      System.out.println( cnt + "\t" +  item + "\t" 
			  + sum + "\t" + smallest + "\t" + biggest);
      item = Console.in.readInt();
    }
  }
  static int min(int a, int b) {
    if (a < b)
      return a;
    else
      return b;
  }
static int max(int a, int b) {
  if (a > b)
    return a;
  else
    return b;
}
}
