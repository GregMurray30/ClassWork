class Fcn {
  static int foo(int a, int b) { return (a + b); }
  static int goo(int x) { return (x * x); }
  public static void main(String[] args) {
    int i = 2;
    System.out.println("foo = " + foo(i, 3));
    System.out.println("foo = " + foo(i, 4));
    System.out.println("goo = " + goo(i));
    System.out.println("goo = " + foo(goo(i), i++));
  }
}
