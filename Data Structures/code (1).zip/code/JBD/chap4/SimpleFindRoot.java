// SimpleFindRoot.java - find the root of x*x - 2
//Version 1.0 Wont work- Why?
class SimpleFindRoot {
  public static void main(String[] args) {
    double a = 0.0, b = 10.0, x, step = 0.001;

    x = a; /* start at one end */
    while ( f(x) != 0.0 && x < b) {
      x = x + step;
    }
    if (x < b)
      System.out.println(" root is " + x);
    else
      System.out.println(" root not found");
  }
  static double f(double x){ return (x * x - 2.0);}
}
