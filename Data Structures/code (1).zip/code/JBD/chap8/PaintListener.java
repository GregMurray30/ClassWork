//PaintListener.java - do the actual drawing
import java.awt.*;
import java.awt.event.*;

public class PaintListener implements 
    MouseMotionListener
{
  public void mouseDragged(MouseEvent e) {
    DrawingCanvas canvas = 
                    (DrawingCanvas)e.getSource();
    Graphics g = canvas.getGraphics();
    g.fillOval(e.getX() - radius, e.getY() - radius,
               diameter, diameter);
  }
  public void mouseMoved(MouseEvent e){}
  private int radius = 3;
  private int diameter = radius * 2;
}
