// DrawingCanvas.java - a blank Canvas
import java.awt.*;
import javax.swing.*;

class DrawingCanvas extends JComponent {
  public Dimension getMinimumSize() {
    return new Dimension(SIZE, SIZE);
  }
  public Dimension getPreferredSize() {
    return new Dimension(SIZE, SIZE);
  }
  private static final int SIZE = 500;
}
