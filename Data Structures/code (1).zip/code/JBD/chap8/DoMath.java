//DoMath.java - respond to two different buttons
import javax.swing.*;
import java.awt.event.*;

class DoMath implements ActionListener {

  DoMath(JTextField first, JTextField second,
         JTextField result)
  {
    inputOne = first;
    inputTwo = second;
    output = result;
  }
  public void actionPerformed(ActionEvent e) {
    double first, second;
    first =
        Double.parseDouble(inputOne.getText().trim());
    second =
        Double.parseDouble(inputTwo.getText().trim());
    if (e.getActionCommand().equals("Add"))
      output.setText(String.valueOf(first + second));
    else
      output.setText(String.valueOf(first - second));
  }

  private JTextField inputOne, inputTwo, output;
}
