// PaintListener2.java - paints on an DrawingCanvas2,
// and it's associated offscreen image.
import java.awt.*;
import java.awt.event.*;

public class PaintListener2 implements
    MouseMotionListener
{
  public void mouseDragged(MouseEvent e) {
    DrawingCanvas2 canvas =
                     (DrawingCanvas2)e.getSource();
    Graphics g = canvas.getGraphics();
    g.fillOval(e.getX() - radius, e.getY() - radius, 
               diameter, diameter);
    // duplicate the drawing on the offscreen image
    Image image = canvas.getOffscreenImage();
    g = image.getGraphics();
    g.fillOval(e.getX() - radius, e.getY() - radius,
               diameter, diameter);
  }
  public void mouseMoved(MouseEvent e){}
  
  protected int radius = 3;
  protected int diameter = radius * 2;
  
}
