// SampleAWT.java - source for screen shot in intro to chap 8
import javax.swing.*;
import java.awt.*;

class SampleAWT
{
  public static void main(String[] args)
  {
    JFrame frame = new JFrame("Sample AWT Components");
    Container display = frame.getContentPane();
    display.setLayout(new FlowLayout());
    display.add(new JLabel("What programming languages do you know?"));
    display.add(new JLabel("Check all that apply:"));
    display.add(new JCheckBox("Java",true));
    display.add(new JCheckBox("C",true));
    display.add(new JCheckBox("C++",true));
    display.add(new JButton("Submit"));
    JCheckBox perlbox = new JCheckBox("Perl", true);
    display.add(perlbox);
    frame.pack();
    frame.show();
    System.out.println("Goodbye from main()");
  }
}
