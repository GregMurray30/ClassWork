// MiniCalcApplet.java
/* <applet code="MiniCalcApplet.class" width=200 height=100></applet> */
import javax.swing.*;
import java.awt.*;

public class MiniCalcApplet extends JApplet {
  public void init() {
    Container pane = getContentPane();
    // create the major components
    JTextField firstNumber = new JTextField(20);
    JTextField secondNumber = new JTextField(20);
    JTextField result = new JTextField(20);
    JButton addButton = new JButton("Add");
    JButton subButton = new JButton("Subtract");
    // there will be 4 rows of 2 components each
    pane.setLayout(new GridLayout(4, 2));
    // add all of the components to the content pane
    pane.add(new JLabel("Enter a number"));
    pane.add(firstNumber);
    pane.add(new JLabel("Enter a number"));
    pane.add(secondNumber);
    pane.add(new JLabel("Result"));
    pane.add(result);
    pane.add(addButton);
    pane.add(subButton);
    // setup the listener, listening to the buttons
    DoMath listener = 
        new DoMath(firstNumber, secondNumber, result);
    subButton.addActionListener(listener);
    addButton.addActionListener(listener);
  }
}
