//HelloGoodBye.java -
import java.awt.*;
import javax.swing.*;

class HelloGoodBye {
  public static void main(String[] args) {
    JFrame frame = new JFrame("HelloGoodBye");
    Container pane = frame.getContentPane();
    Button hello = new Button("Hello, world!");
    GoodBye listener = new GoodBye();
    hello.addActionListener(listener);
    pane.add(hello);
    frame.pack(); 
    frame.show(); 
  }
}
