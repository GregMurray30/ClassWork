//StarTestQuit.java - added a quit button to StarTest
import java.awt.*;
import javax.swing.*;
class StarTestQuit {
  public static void main(String[] args) {
    JFrame frame = new JFrame("StarTest");
    Container pane = frame.getContentPane();
    Star star = new Star();
    //Changes from StarTest are below here
    JButton quit = new JButton("Quit");
    pane.setLayout(new FlowLayout());
    quit.addActionListener(new GoodBye());
    pane.add(quit);
    //Changes from StarTest are above here
    pane.add(star);
    frame.pack();
    frame.show();
  }
}
