//SimplePaint2.java - a program to draw with the mouse
import java.awt.*;
import javax.swing.*;

class SimplePaint2 {
  public static void main(String[] args) {
    JFrame frame = new JFrame("SimplePaint");
    Container pane = frame.getContentPane();
    DrawingCanvas2 canvas = new DrawingCanvas2();
    PaintListener2 listener = new PaintListener2();
    canvas.addMouseMotionListener(listener);
    pane.add(canvas);
    frame.pack();
    frame.show();
  }
}
