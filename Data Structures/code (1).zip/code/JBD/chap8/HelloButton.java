//HelloButton.java
import java.awt.*; 
import javax.swing.*;

class HelloButton { 
  public static void main(String[] args) { 
    JFrame frame = new JFrame("HelloButton");
    Container pane = frame.getContentPane();
    JButton hello = new JButton("Hello, world!");
    pane.add(hello); 
    frame.pack(); 
    frame.show(); 
  }
}
