//SimplePaintCombined.java - combine all of the
//  features of SimplePaint, PaintListener, and
//  DrawingCanvas into a single class.
//  This style of programming isn't recommended.

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class SimplePaintCombined
  extends JComponent implements MouseMotionListener 
{
  public static void main(String[] args) {
    JFrame frame = new JFrame("SimplePaint");
    Container pane = frame.getContentPane();
    SimplePaintCombined canvas = 
      new SimplePaintCombined();
    canvas.addMouseMotionListener(canvas);
    pane.add(canvas);
    frame.pack();
    frame.show();
  }
  public void mouseDragged(MouseEvent e) {
    SimplePaintCombined canvas = 
      (SimplePaintCombined)e.getSource();
    Graphics g = canvas.getGraphics();
    g.fillOval(e.getX() - 3, e.getY() - 3, 6, 6);
  }

  public void mouseMoved(MouseEvent e) {}
  public Dimension getMinimumSize() {
    return new Dimension(SIZE, SIZE);
  }
  public Dimension getPreferredSize() {
    return new Dimension(SIZE, SIZE);
  }
  private static final int SIZE = 500;
}
