//DrawingCanvas2.java - remember drawing operations
// using an offscreen image
import java.awt.*;
import javax.swing.*;

class DrawingCanvas2 extends JComponent {
  // transfer the offscreen image to the screen
  public void paint(Graphics g) {
    if (offscreenImage != null)
      g.drawImage(offscreenImage,0,0,SIZE,SIZE,null);
  }
  // return the offscreen image, if one doesn't exist
  // create one
  public Image getOffscreenImage() {
    if (offscreenImage == null)
      offscreenImage = createImage(SIZE, SIZE);
    return offscreenImage;
  }
  public Dimension getMinimumSize() {
    return new Dimension(SIZE, SIZE);
  }
  public Dimension getPreferredSize() {
    return new Dimension(SIZE, SIZE);
  }
  private static final int SIZE = 500;
  private Image offscreenImage;
}
