//SimplePaint.java - a program to draw with the mouse
import java.awt.*;
import javax.swing.*;

class SimplePaint {
  public static void main(String[] args) {
    JFrame frame = new JFrame("SimplePaint");
    Container pane = frame.getContentPane();
    DrawingCanvas canvas = new DrawingCanvas();
    PaintListener listener = new PaintListener();
    canvas.addMouseMotionListener(listener);
    pane.add(canvas);
    frame.pack();
    frame.show();
  }
}
