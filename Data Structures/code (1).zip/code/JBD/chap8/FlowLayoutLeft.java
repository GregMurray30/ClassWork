//FlowLayoutLeft.java
import java.awt.*;
import javax.swing.*;

class FlowLayoutLeft {
  public static void main(String[] args) {
    JFrame frame = new JFrame("FlowLayout.LEFT");
    Container pane = frame.getContentPane();
    pane.setLayout(new FlowLayout(FlowLayout.LEFT));
    pane.add(new JButton("Button 1"));
    pane.add(new JLabel("Label 2"));
    pane.add(new JButton("Button 3"));
    pane.add(new JLabel("Label Four (4)"));
    pane.add(new JButton("Button 5"));
    frame.pack();
    frame.show();
  }
}
