//SimplePaintApplet.java - applet version of program
//    that draws with the mouse
/* <applet code="SimplePaintApplet.class" 
width=500 height=500> </applet> */
import java.awt.*;
import javax.swing.*;

public class SimplePaintApplet extends JApplet {
  public void init() {
    Container pane = getContentPane();
    DrawingCanvas2 canvas = new DrawingCanvas2();
    PaintListener2 listener = new PaintListener2();
    canvas.addMouseMotionListener(listener);
    pane.add(canvas);
  }
}
