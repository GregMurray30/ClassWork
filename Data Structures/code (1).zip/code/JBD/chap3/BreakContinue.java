// BreakContinue.java - example of break and continue
import tio.*;

class BreakContinue {
  public static void main(String[] args) {
    int n;

    while (true) {      //seemingly an infinite loop
      System.out.print("Enter a positive integer ");
      System.out.print("or 0 to exit:");
      n = Console.in.readInt();
      if (n == 0)
        break;          // exit loop if n is 0
      if (n < 0)
        continue;       //wrong value
      System.out.print("squareroot of " + n);
      System.out.println(" = " +Math.sqrt(n));
      //continue land here at end of current iteration
    }
    //break lands here
    System.out.println("a zero was entered");
  }
}
