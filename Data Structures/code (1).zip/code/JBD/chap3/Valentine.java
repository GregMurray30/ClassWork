// Valentine.java - a simple while loop
class Valentine {
  public static void main(String[] args) {
    int howMuch = 0;

    while (howMuch++ < 5)
      System.out.println("I love you.");
  }
}
