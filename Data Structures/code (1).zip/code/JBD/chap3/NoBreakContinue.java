// NoBreakContinue.java - avoiding break and continue
import tio.*;

class NoBreakContinue {
  public static void main(String[] args) {
    int n;
    
    System.out.print("Enter a positive integer ");
    System.out.print("or 0 to exit:");
    n = Console.in.readInt();
    while (n != 0) {
      if (n > 0) {
        System.out.print("squareroot of " + n);
        System.out.println(" = " +Math.sqrt(n));
      }
      System.out.print("Enter a positive integer ");
      System.out.print("or 0 to exit:");
      n = Console.in.readInt();
    }
    //break lands here
    System.out.println("a zero was entered");
  }
}
