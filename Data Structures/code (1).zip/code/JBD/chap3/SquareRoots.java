// SquareRoots.java - print square roots of 1 - 10
public class SquareRoots {
  public static void main(String[] args) {
    int i;
    double square_root;

    for (i = 1; i <= 10; i++) {
      square_root = Math.sqrt(i);
      System.out.println("the square root of " + i +
                         " is " + square_root);
    }
    System.out.println("That's All!");
  }
}
