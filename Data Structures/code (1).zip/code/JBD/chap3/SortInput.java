// SortInput.java - sort three numbers
import tio.*; // use the package tio 

class SortInput {
  public static void main (String[] args) {
    int a, b, c, t;

    System.out.println("type three integers:");
    a = Console.in.readInt();
    b = Console.in.readInt();
    c = Console.in.readInt();
    if (a > b) {
      t = a;
      a = b;
      b = t;
    }
    if (b > c) {
      t = b;
      b = c;
      c = t;
    }
    if (a > b) {
      t = a;
      a = b;
      b = t;
    }
    System.out.print("The sorted order is : ");
    System.out.println(a + ", " + b + ", " + c);
  }
}
