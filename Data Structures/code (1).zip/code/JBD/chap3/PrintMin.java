//PrintMin.java - print the smaller of two numbers
import tio.*;

class PrintMin {
  public static void main(String[] args) {
    System.out.println("Type two integers.");
    int x = Console.in.readInt();
    int y = Console.in.readInt();

    if (x < y)
      System.out.println("The smaller is " + x);
    if (y < x)
      System.out.println("The smaller is " + y);
    if (x == y)
      System.out.println("They are equal.");
  }
}
