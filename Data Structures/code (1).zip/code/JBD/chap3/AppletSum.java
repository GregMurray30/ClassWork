/* <applet code="AppletSum.class"
    width=420 height=100></applet> */
//AppletSum.java - Text input with an applet
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class AppletSum extends JApplet
    implements ActionListener {
  JTextField inputOne = new JTextField(20);
  JTextField inputTwo = new JTextField(20);
  JTextField output = new JTextField(20);
  public void init() {
    Container pane = getContentPane();

    pane.setLayout(new FlowLayout());
    pane.add(new JLabel("Enter one number."));
    pane.add(inputOne);
    pane.add(
      new JLabel("Enter a number and hit return."));
    pane.add(inputTwo);
    pane.add(new JLabel("Their sum is:"));
    pane.add(output);
    inputTwo.addActionListener(this);
  }
  public void actionPerformed(ActionEvent e) {
    double first, second, sum;

    first = Double.parseDouble(inputOne.getText());
    second = Double.parseDouble(inputTwo.getText());
    sum = first + second;
    output.setText(String.valueOf(sum));
  }
}
