// SquareRoots2.java - replace for with while
public class SquareRoots2 {
  public static void main(String[] args) {
    int i;
    double square_root;

    i = 1;               // initialization-expr
    while (i <= 10) {
      square_root = Math.sqrt(i);
      System.out.println("the square root of " + i +
                         " is " + square_root);
      i++;               // iteration-expr
    }
    System.out.println("That's All!");
  }
}
