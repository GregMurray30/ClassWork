// Average.java - compute average of input values
import tio.*;

public class Average {
  public static void main(String[] args) {
    double number;
    int count = 0;
    double runningTotal = 0;
    // initialization before first loop iteration
    System.out.println("Type some numbers, "+
        "the last one being 0");
    number = Console.in.readDouble();
    while (number != 0) {
      runningTotal = runningTotal + number;
      count = count + 1;
      // prepare for next iteration
      number = Console.in.readDouble();
    }
    System.out.print("The average of the ");
    System.out.print(count);
    System.out.print(" numbers is ");
    System.out.println(runningTotal/count);
  }
}
