// ExceptionExample.java - catch an exception
import tio.*;

public class ExceptionExample {
  public static void main(String[] args) {
    int aNumber = 0;
    boolean success = false;
    String inputString = "";

    System.out.println("Type an integer.");
    while (!success) {
      try {
        aNumber = Console.in.readInt();
        success = true;
      }
      catch (NumberFormatException exception) {
        inputString = Console.in.readWord();
        System.out.println(inputString + 
              " is not an integer. Try again!");
      }
    }
    System.out.println("You typed " + aNumber);
    // continue with code to process aNumber
  }
}
