public class ReadException extends RuntimeException{
  public ReadException() {
    super();
  }
  public ReadException(String message) {
    super(message);
  }
}
