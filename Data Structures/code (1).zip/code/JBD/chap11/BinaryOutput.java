// BinaryOutput.java - create a sample binary file
import java.io.*;

class BinaryOutput {
  public static void main(String[] args)
       throws IOException
  {
    DataOutputStream output = null;
    if (args.length != 1) {
      System.out.println("Usage: " +
          "java BinaryOutput filename");
      System.exit(1);
    }
    try {
      output = new DataOutputStream(
                   new FileOutputStream(args[0]));
    }
    catch (IOException e) {
      System.out.println("Could not open " + args[0]);
      System.out.println(e);
      System.exit(1);
    }
    for (int i = 1; i <= 10; i++)
      output.writeInt(i * 100);
  }
}
