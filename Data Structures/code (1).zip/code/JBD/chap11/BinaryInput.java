// BinaryInput.java - read some integers from 
//     a binary file
import java.io.*;

class BinaryInput {
  public static void main(String[] args)
       throws IOException
  {
    DataInputStream input = null;
    if (args.length != 1) {
      System.out.println("Usage: " +
          "java BinaryInput filename");
      System.exit(1);
    }
    try {
      input = new DataInputStream(
                  new FileInputStream(args[0]));
    }
    catch (IOException e) {
      System.out.println("Could not open " + args[0]);
      System.out.println(e);
      System.exit(1);
    }
    // count is used to print 4 values per line
    int count = 0;
    try {
      while (true) {
        int myData = input.readInt();
        count++;
        System.out.print(myData + " ");
        // print a newline every 4th value
        if (count % 4 == 0)
          System.out.println();
      }
    }
    catch (EOFException e)
    {
      // just catch the exception and
      // discard it
    }
    // add a newline after the last partial line
    // if necessary
    if (count % 4 != 0)
      System.out.println();
  }
}
