// TwoCatchExample.java - use two catch clauses
import tio.*;

public class TwoCatchExample {
  public static void main(String[] args) {
    int aNumber = 0;
    boolean success = false;
    String inputString = "";

    System.out.println("Type an integer.");
    while (!success) {
      try {
        aNumber = Console.in.readInt();
        success = true;
        System.out.println("You typed " + aNumber);
      }
      catch (NumberFormatException exception) {
        inputString = Console.in.readWord();
        System.out.println(inputString + 
              " is not an integer. Try again!");
      }
      catch (tio.ReadException exception) {
        System.out.println(
              "Continuing with default value 0.");
        aNumber = 0;
        success = true;
      }
    }
    // continue with code to process a_number
  }
}
