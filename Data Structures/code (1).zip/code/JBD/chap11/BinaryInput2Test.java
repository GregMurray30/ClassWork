// BinaryInput2Test.java - demo finally
//     this example is not in the text
import java.io.*;

class BinaryInput2Test {
  public static void main(String[] args)
       throws IOException
  {
    DataInputStream input = null;
    if (args.length != 2) {
      System.out.println("Usage: " +
          "java BinaryInput2Test filename howManyToRead");
      System.exit(1);
    }
    BinaryInput2.readBinaryInput(args[0], Integer.parseInt(args[1]));
  }
}
