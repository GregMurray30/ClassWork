// ExceptionExampleTwo.java - show control flow when
//   an exception occurs during nested method calls
import tio.*;

class ExceptionExampleTwo {

  public static void main(String[] args) {
    int x = 0;
    System.out.println("main starting");
    try {
      x = callOne();
      System.out.println("callOne OK x = " + x);
    }
    catch (ArithmeticException e) {
      System.out.println("callOne not OK: " + e);
      x = -1;
    }
    System.out.println("main exiting x = " + x);
  }
  static int callOne() {
    System.out.println("callOne starting");
    int result = callTwo();
    System.out.println("callOne returning result = " 
                       + result);
    return result;
  }
  static int callTwo() {
    int num = 0;
    System.out.println("type a number");
    int input = Console.in.readInt();
    num = 1000 / input;
    System.out.println("callTwo returning num = " 
                       + num);
    return num;
  }
}
