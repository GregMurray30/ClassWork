class ExceptionReview {

  public static void main(String[] args) {
    int x;
    try {
      x = foo(10);
    }
    catch (MyException e) {
      System.out.println("Caught an exception: " +
                          e);
      x = 99;
    }
    System.out.println(x);
  }
  static int foo(int x) {
    System.out.println("foo started with " + x);
    int temp = bar(x);
    System.out.println("foo returning " + temp);
    return temp;
  }
  static int bar(int y) {
    System.out.println("bar started with " + y);
    if (y > 0)
      throw new MyException("just a test");
    System.out.println("when is this executed?");
    return y;
  }
}
