// BinaryInput2.java - read some integers from 
//     a binary file
import java.io.*;

class BinaryInput2 {
  public static int readBinaryInput(String filename,
                                     int howMany)
       throws IOException
  {
    DataInputStream input = null;
    try {
      input = new DataInputStream(
                  new FileInputStream(filename));
    }
    catch (IOException e) {
      System.out.println("Could not open " +filename);
      System.out.println(e);
      throw e;
    }
    int count = 0;
    try {
      while (count < howMany) {
        int myData = input.readInt();
        count++;
        System.out.print(myData + " ");
        // print a newline every 4th value
        if (count % 4 == 0)
          System.out.println();
       }
    }
    catch (EOFException e) {
      // just catch the exception and discard it
    }
    finally {
      if (count % 4 != 0)
        System.out.println();
      if (input != null)
        input.close();
    }
    return count;
  }
}
