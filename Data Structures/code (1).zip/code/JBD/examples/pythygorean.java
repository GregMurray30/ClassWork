
/** Pythagorean.java
*   Purpose
*   Test multiple loops for  a*a + b*b = c*c
    Problem 16 chapter 3 variant
* Author:  Ira Pohl
* Version 1.0
* Date January 19, 1999
*/


public class Pythagorean {
   public static void main(String args[]) {
     int a, b, c;
     int n = 200;

     for(a = 1; a <= n; a++){
       for(b = 1; b <= n; b++){
         for(c = 1; c <= n; c++){
	    if( a*a + b*b == c*c)
	      System.out.println(" TRIPLE IS = " + a + " ," + b + " ," +c);
         }
       }
     }

   }
}
