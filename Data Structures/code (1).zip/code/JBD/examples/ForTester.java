/* the for loop tester
 * an exercise for java students who want practice figuring out for loops
 * Doug Whitmore 1999
 */

public class ForTester
{
	public static void main(String args[])
	{
		int endCondition1 = 10, endCondition2 = 20, endCondition3 = 100;
		int startCondition2;
		int increment1 = 10, increment2 = -1;
		
		System.out.println("for(int i = 0; i < endCondition1; i++)");
		for(int i = 0; i < endCondition1; i++)
		{
			System.out.println("i = " + i);
		}

		startCondition2 = 10;
		System.out.println("for(int i = startCondition2; i < endCondition2; i++)");
		for(int i = startCondition2; i < endCondition2; i++)
		{
			if(i < 10)
				System.out.println("i is less than 10");
			if(i == 12)
				i += 2;
			else
				System.out.println("i = " + i);
		}

		System.out.println("for(increment2 = 10; increment2 < endCondition3; increment2 += increment1)");
		for(increment2 = 10; increment2 < endCondition3; increment2 += increment1)
		{
			int j = 0;
			while(j < 10)
			{
				if(j == 5)
					j += 3;
				else
				{
					System.out.print("  j = " + j);
					j++;
				}
			}
			System.out.println("\ni = " + increment2);
		}
		System.out.println("increment2 = " + increment2);

		System.out.println("This is a tougher one...");
		System.out.println("for(int i = 20; i > 0; i -= 2)");
		for(int i = 20; i > 0; i -= 2)
		{
			if(i < 10)
				i++;
			if(i == 7)
				System.out.println("wow! i = " + i);
			else
				System.out.println(" i = " + i);
		}
	}//end of main
}//end of class