
class Counter2 {
   int value; //0 to 99
   void reset() { value = 0; }     //set to 0
   int get() { return value;}   //current value
   void click() { value = (value + 1) % 100;}
   Counter2 add(Counter2 a, Counter2 b)
   {
      value = (a.value + b.value) % 100;
      Counter2 temp = new Counter2();
      temp.value = value;
      return temp;
   }
}

// Counter2Test.java - demonstration of class Counter2
class Counter2Test{
  public static void main(String[] args)
  {
    Counter2 c1 = new Counter2(); //create a Counter
    Counter2 c2 = new Counter2(); //create another
    Counter2 c3 = new Counter2(), c4;
    c1.click();  //c1.value = (c1.value + 1) % 100
    c2.click();
    c2.click();
    c4 = c3.add(c1, c2);  
    System.out.println("Counter2 value is " + c1.get());
    System.out.println("Counter2 value is " + c2.get());
    System.out.println("Counter2 value is " + c3.get());
    System.out.println("Counter2 value is " + c4.get());
  }
}
