From pohl@cse.ucsc.edu Wed Jan 20 13:24:07 1999
Date: Tue, 19 Jan 1999 21:01:37 -0800 (PST)
From: Ira Pohl <pohl@cse.ucsc.edu>
To: whitmore@cse.ucsc.edu
Subject: post to web




/** Max.java
*   Purpose
*   Pick the largest number input
*   Demonstrates tio using readInt to get input.
* Author:  Ira Pohl
* Version 1.0
* Date January 19, 1999
*/

import tio.*;    //class developed terminal input package

public class Max {
   public static void main(String args[]) {
     int max = 0, n = 1;
     
     while (n > 0){
        System.out.println("Enter int n > 0 ");
        n = Console.in.readInt();
        if ( n > max)
	   max = n;
     }
     System.out.println("maximum int is " + max);

   }
}
