//Example program from last Thursday's lecture

/** Circle.java
*   Purpose
*   Simple area calculation for a circle.
*   Demonstrates tio using readDouble to get input.
* Author:  Ira Pohl
* Version 1.0
* Date January 13, 1999
*/

import tio.*;    //class developed terminal input package

public class Circle {
   public static void main(String args[]) {
     double radius, area;
     double pi = 3.14159; //later will see that pi is in Java library

     System.out.println("Enter radius >= 0 ");
     radius = Console.in.readDouble();

     System.out.println("Circles radius = " + radius);
     area = pi * radius * radius;
     System.out.println("Circles Area = " + area);
   }
}
