class Spaceship3 {
	public static void main(String[] args) {

		int[] redCounts = { 100, 232, 101 };
		int[] blueCounts = { 1, 2, 1 };
		
		blueCounts = redCounts;
		blueCounts[0]++;
		
		System.out.println("redCounts[0] is " + redCounts[0]);
	}
}

/*
 * What does it show?
 * A. 1
 * B. 2
 * C. 100
 * D. 101
 * E. Something else
 */
