import java.util.*;

class Exception3 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int x = 0;
		try {
			x = 1000 / scanner.nextInt();
		} catch (Exception exc) {
			System.out.println("There was a problem.");
			System.out.println("Exception was: " + exc);
		}
		System.out.println("Calculation 1000 / your number is: " + x);
	}
}

