//StarTest.java - display a starburst
import java.awt.*;
import javax.swing.*;

class Star extends JComponent {
  public void paint(Graphics g) {
    for (double angle = 0; angle < Math.PI; 
        angle = angle + Math.PI / 16) {
      double x1, x2, y1, y2;
      // compute coordinates of endpoints of a line
      // cosine and sine range from -1 to 1
      // multiplying by RADIUIS gives changes the
      // range to be from -RADIUS to RADIUS
      // adding RADIUS gives the final range of
      // 0 to 2 * RADIUS
      x1 = Math.cos(angle) * RADIUS + RADIUS;
      y1 = Math.sin(angle) * RADIUS + RADIUS;
      x2 = Math.cos(angle + Math.PI) * RADIUS +RADIUS;
      y2 = Math.sin(angle + Math.PI) * RADIUS +RADIUS;
      g.drawLine((int)x1, (int)y1, (int)x2, (int)y2);
    }
  }
  // make the JComponent big enough to show the image
  public Dimension getMinimumSize() {
    return new Dimension(2 * RADIUS, 2 * RADIUS);
  }
  public Dimension getPreferredSize() {
    return new Dimension(4 * RADIUS, 4 * RADIUS);
  }
  private static final int RADIUS = 100;
}

class StarTest {
  public static void main(String[] args) {
    JFrame frame = new JFrame("StarTest");
    Container pane = frame.getContentPane();
    Star star = new Star();
    pane.add(star);
    frame.pack();
    frame.show();
  }
}
