
class BreakTest1 {
	public static void main(String[] args) {
		for(int i = 0; i < 100; i++) {
			System.out.println(i);
			if (i == 7) break;
		}
		System.out.println("Done");
	}
}

