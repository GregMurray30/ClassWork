import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.plugins.jpeg.JPEGImageWriteParam;
import javax.imageio.stream.ImageOutputStream;

class ImageTest {

	//===================================//
	// reads in an image                 //
	//===================================//
	public static BufferedImage readImage(String fname) throws Exception {
		BufferedImage image = ImageIO.read(new File(fname));
		return image;
	}

	//===================================//
	// saves file                        //
	//===================================//
	public static void saveImage(BufferedImage img, File file) throws IOException {
		ImageWriter writer = null;
		java.util.Iterator iter = ImageIO.getImageWritersByFormatName("jpg");

		if(iter.hasNext()) {
			writer = (ImageWriter)iter.next();
		}

		ImageOutputStream ios = ImageIO.createImageOutputStream(file);
		writer.setOutput(ios);

		ImageWriteParam param = new JPEGImageWriteParam(java.util.Locale.getDefault());
		param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT) ;
		param.setCompressionQuality(0.98f);

		writer.write(null, new IIOImage(img, null, null), param);
	}

	static void manipulate(BufferedImage img) {
		for(int i = 0; i < img.getWidth(); i++) {
			for(int j = 0; j < img.getHeight(); j++) {
				Color col = new Color(img.getRGB(i, j));
                int r = col.getRed();
                int g = col.getGreen();
                int b = col.getBlue();
                r = 0;
                g = 0;
                Color newcol = new Color(r, g, b);
				img.setRGB(i, j, newcol.getRGB());
			}
		}
	}

	// Make a copy
/*
 	static BufferedImage deepCopy(BufferedImage bi) {
		ColorModel cm = bi.getColorModel();
		boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
		WritableRaster raster = bi.copyData(null);
		return new BufferedImage(cm, raster, isAlphaPremultiplied, null);
	}
*/

	public static void main(String[] args) throws Exception {
		System.out.println("Loading");
		BufferedImage img = readImage("rose.jpg");
		manipulate(img);
		saveImage(img, new File("roseOUT.jpg"));
	}

}

