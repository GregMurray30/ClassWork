class Counter {
	int value;		// instance variable
	void reset() {	// mutator method
		value = 0;
	}
	int get() {		// accessor method
		return value;
	}
	void click() {
		value = (value + 1) % 100;
	}
}

class SimpleClass3 {
	public static void main(String[] args) {
		Counter c1 = new Counter();
		Counter c2 = new Counter();

		c1.reset();
		c2 = c1;
		c1.click();
		c2.click();
		c1.click();
		c1.click();
		System.out.println(c1.get());
		System.out.println(c2.get());
	}
}
