interface Speakable {
	void speak() {
		System.out.println("HIYA");
	}
}

interface Groomable {
	void groom();
	int findTicks(); // returns ticks found
}

class Dog implements Speakable, Groomable {
	int age;
	Dog() { age=0; }
	public void speak() {
		System.out.println("Hello, good sir.");
	}
	public void groom() {
		System.out.println("Ah, that feels good.");
	}
 	public int findTicks() {
		return 5 + age * age;
	}
}

class Cat implements Speakable {
	public void speak() {
		System.out.println("Meow");
	}
}

class InterfaceExample {
	public static void main(String[] args) {
		Dog wilfred = new Dog();
		wilfred.speak();
		Speakable p = wilfred;
		p.speak();
		p = new Cat();
		p.speak();
	}
}

