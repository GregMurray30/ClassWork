class Sieve2 {
	
	static void crossOut(boolean[] array, int x) {
		for(int i = x + x; i < array.length; i += x) {
			array[i] = false;
		}
	}

	static void showTable(boolean[] array) {
		for (int i = 2; i < array.length; i++) {
			if (array[i] == true) {
				System.out.print(i + " ");
			} else {
				System.out.print("* ");
			}
			if (i % 20 == 0) {
				System.out.println();
			}
		}
		System.out.println("\n");
	}

	public static void main(String[] args) {
		
		int N = 100; // Maximum tested value
		boolean table[] = new boolean[N];
		for(int i = 0; i < N; i++) {
			table[i] = true;
		}
		table[0] = false;
		table[1] = false;
		for(int i = 2; i < Math.sqrt(N); i++) {
			if (table[i]) {
				crossOut(table, i);
				showTable(table);
			}
		}
		for(int i = 0; i < N; i++) {
			if (table[i]) {
				System.out.print(i + " ");
			}
		}
		System.out.println();
		
	}
}
