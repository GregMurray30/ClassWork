class FunctionQuiz1alt {
	public static void main(String[] args) {
		foo();
	}
	static void foo() {
			bar();
	}
	static void bar() {
			System.out.println("Spam");
			return;
//			foo();
	}
}

