abstract class Animal {
	protected String dna;
	abstract public void speak();
	abstract public int numLegs();
}

abstract class Mammal extends Animal {
	protected double lungCapacity;
	protected double bloodTemp;
	abstract public void breath();
//	abstract public void groom();
}

class Dog extends Mammal {
	private int numTicks;
	Dog() {
		lungCapacity = 1.3;
		bloodTemp = 32.1;
		numTicks = 5;
	}
	public void speak() {
		System.out.println("Woof!");
	}
	public int numLegs() {
		return 4;
	}
	public void breath() {
		lungCapacity += 0.2;
	}
	public void groom() {
		numTicks--;
		System.out.println("Ahh, that's better");
	}
}

class AbstractAnimalExample {
	public static void main(String[] args) {
		Mammal ashley = new Dog();
		ashley.groom();
	}
}
