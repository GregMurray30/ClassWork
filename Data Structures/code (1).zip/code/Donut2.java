import java.util.Scanner;

class Donut2 {
	public static void main(String[] args) {
		System.out.println("How many donuts?");
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		if (n % 4 == 0) {
			System.out.format("Order %d packs of 4\n", n / 4);
			System.exit(0);
		}
		System.out.println("Can't order that many");
	}
}


