class Counter {
	private int value;
	static int maxCount = 3;

	Counter() {
		value = 0;
	}
	public int get() {
		return value;
	}
	public void click() {
		value++;
		if (get() >= maxCount) {
			value = 0;
		}
	}
	public String toString() {
		return "Count is " + value;
	}
	public static int getMaxCount() {
		return maxCount;
	}
}

class SimpleClass10 {
	
	public static void main(String[] args) {
		Counter c1 = new Counter();

		c1.click();
		c1.click();
		c1.click();
		c1.click();
		System.out.println(c1);
		System.out.println(Counter.getMaxCount());
	}
}
