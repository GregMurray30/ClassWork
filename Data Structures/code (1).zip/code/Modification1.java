class Modification1 {
	
	static void messAround(int[] thing) {
		thing[2] = 808;
	}
	
	public static void main(String[] args) {
		int[] a = { 1, 532, 3, 99 };

		System.out.println("Original values of a");
		for(int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		
		messAround(a);

		System.out.println("New values of a");
		for(int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		
	}
}
