class Frob {
	private int sekrit;
	Frob(int v) {
		sekrit = v;
	}
}

class EqualsTest {
	public static void main(String[] args) {
		Frob a = new Frob(3);
		Frob b = new Frob(10);
		Frob c = new Frob(3);
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(a == b);
		System.out.println(a.equals(c));
	}
}
