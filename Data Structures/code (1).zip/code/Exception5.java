class Exception5 {
	public static int foo(int x) {
		int y = 3;
		y += bar(x);
		System.out.println("Inside foo");
		return y;
	}
	
	public static int bar(int x) {
		System.out.println("Inside bar");
		return 100 / x;
	}

	public static void main(String[] args) {
		int r = 0;
		try {
			r = foo(10);
		} catch (Exception e) {
			System.out.println("There was a problem.");
		}
		System.out.println("Result is " + r);
	}
}

