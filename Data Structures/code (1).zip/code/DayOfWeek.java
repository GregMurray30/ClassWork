
class DayOfWeek {
	public static void main(String[] args) {
		int day = 3; // Wednesday
		// Let's advance 10000 days
		day += 10000;
		day %= 7; // Keep it within 0-6
		if (day == 0) {
			System.out.println("Sunday");
		} else if (day == 1) {
			System.out.println("Monday");
		} else if (day == 2) {
			System.out.println("Tuesday");
		} else if (day == 3) {
			System.out.println("Wednesday");
		} else if (day == 4) {
			System.out.println("Thursday");
		} else if (day == 5) {
			System.out.println("Friday");
		} else if (day == 6) {
			System.out.println("Saturday");
		} else {
			System.out.println("Illegal day");
		}
	}
}

