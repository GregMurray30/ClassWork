
import java.util.*;

class Pepy4 {
	public static void main(String[] args) {
		System.out.println("Let's solve Pepy's problem\n");
		
		// Generate a random integer, 1-6
		Random rnd = new Random();

		// First version: have to get 1 or more 1 rolls out of 6 dice
		int successes = 0;
		for (int trial = 0; trial < 10000000; trial++) {
			int numOnes = 0;
			for(int i = 0; i < 6; i++) {
				int n = rnd.nextInt(6) + 1;
				if (n == 1) {
					numOnes++;
				}
			}
			if (numOnes >= 1) {
				successes++;
			}
		}

		System.out.format("1: Got %d successes out of 10000000.\n", successes);

		// Second version: have to get 2 or more 1 rolls out of 12 dice
		int successes2 = 0;
		for (int trial = 0; trial < 10000000; trial++) {
			int numOnes = 0;
			for(int i = 0; i < 12; i++) {
				int n = rnd.nextInt(6) + 1;
				if (n == 1) {
					numOnes++;
				}
			}
			if (numOnes >= 2) {
				successes2++;
			}
		}

		System.out.format("2: Got %d successes out of 10000000.\n", successes2);

	}
}

