class Exception7 {
	
	public static int foo(int x) {
		return 100 / x;
	}

	public static void main(String[] args) {
		int r = 0;
		try {
			r = foo(0);
			try {
				r = r + foo(0);
			} catch (Exception e) {
				System.out.println("WARNING");
			}
		} catch (Exception e) {
			System.out.println("DANGER");
		}
		System.out.println("DONE");
	}
}

