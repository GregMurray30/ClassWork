class Spaceship {
	public static void main(String[] args) {
		double[] spaceship;
		double[] planet = { 10.5, -3.3 };
		
		// Start at planet
		planet = spaceship;
		
		// Hyperdrive in x dimension
		spaceship[0] += 100.0;
		
		// Where is the planet?
		System.out.println("Planet is at " + planet[0] + 
			", " + planet[1]);
		System.out.println("Spaceship is at " + spaceship[0]);
	}
}
