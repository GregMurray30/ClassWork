class Animal {
	void talk() {
		System.out.println("I'm an unknown mysterious animal");
	}
	boolean hasFur() {
		return true; // why not
	}
}

class Dog extends Animal {
	void talk() {
		System.out.println("Woof!");
	}
}

class Duck extends Animal {
	void talk() {
		System.out.println("Quack!");
	}
	boolean hasFur() {
		return false;
	}
}

class Inheritance2 {
	public static void main(String[] args) {
		Dog steve = new Dog();
		steve.talk();
		Duck donald = new Duck();
		System.out.println("Donald has fur: " + donald.hasFur());
		Animal arnold = new Dog(); // This is OK, a Dog is an Animal
		arnold.talk(); // What will it say here?
		arnold = new Duck();
		arnold.talk(); // What will it say here?
	}
}
