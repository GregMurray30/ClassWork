class ArrayMinimum {
	
	static int findMinimum(int[] array) {
		int minLoc = 0;
		int minVal = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] < minVal) {
				minLoc = i;
				minVal = array[i];
			}
		}
		return minLoc;
	}

	public static void main(String[] args) {
		int[] theArray = { 45, 2, 1, -32, 99, 101, 23 };
		
		int m = findMinimum(theArray);
		System.out.println("Minimum index is " + m);
	}
}
