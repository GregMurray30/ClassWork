import java.util.Scanner;

class Doubling2 {
	public static void main(String[] args) {
		System.out.println("What is the number?");
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int doublings = (int)Math.ceil(Math.log(n)/Math.log(2.0));
		System.out.format("It takes %d doublings\n", doublings);
	}
}
