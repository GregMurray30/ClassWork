
import java.util.*;

class PepyFunctions {

	static int rollDice(Random rnd) {
		return rnd.nextInt(20) + 1;
	}

	static boolean oneTrial(Random rnd, int numDice, int onesNeeded) {
		int numOnes = 0;
		for(int i = 0; i < numDice; i++) {
			int n = rollDice(rnd);
			if (n == 1) {
				numOnes++;
			}
		}
		if (numOnes >= onesNeeded) {
			return true;
		}
		return false;
	}

	static int attempt(Random rnd, int numDice, int onesNeeded) {
		int successes = 0;
		for (int trial = 0; trial < 10000000; trial++) {
			if (oneTrial(rnd, numDice, onesNeeded)) {
				successes++;
			}
		}
		return successes;
	}

	public static void main(String[] args) {
		System.out.println("Let's solve Pepy's problem\n");
		
		// Generate a random integer, 1-6
		Random rnd = new Random();

		// First version: have to get 1 or more 1 rolls out of 6 dice
		int successes1 = attempt(rnd, 10, 1);
		int successes2 = attempt(rnd, 20, 2);

		System.out.format("1: Got %d successes out of 10000000.\n", successes1);
		System.out.format("2: Got %d successes out of 10000000.\n", successes2);

	}
}

