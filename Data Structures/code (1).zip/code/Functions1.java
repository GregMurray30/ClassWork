class Functions1 {
	public static void main(String[] args) {
		System.out.println("Welcome, Derpina.");
		derp();
		System.out.println("Goodbye, Derpina.");
		System.out.println("Thank you for your contribution.");
	}
	static void derp() {
		System.out.println("Herp!");
		System.out.println("Derp!");
	}
}
