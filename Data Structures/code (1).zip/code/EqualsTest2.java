class Frob {
	private int sekrit;
	Frob(int v) {
		sekrit = v;
	}
	boolean equals(Frob other) {
		if (sekrit == other.sekrit) {
			return true;
		}
		return false;
	}
}

class EqualsTest2 {
	public static void main(String[] args) {
		Frob a = new Frob(3);
		Frob b = new Frob(10);
		Frob c = new Frob(3);
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(a.equals(b));
		System.out.println(a.equals(c));
	}
}
