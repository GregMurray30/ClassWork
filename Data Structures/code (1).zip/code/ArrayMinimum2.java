class ArrayMinimum2 {
	
	static int findMinimum(int[] array, int low, int high) {
		int minLoc = 0;
		int minVal = array[0];
		for (int i = low; i <= high; i++) {
			if (array[i] < minVal) {
				minLoc = i;
				minVal = array[i];
			}
		}
		return minLoc;
	}

	public static void main(String[] args) {
		int[] theArray = { 45, 2, 1, -32, 99, 101, 23 };
		
		int m = findMinimum(theArray, 4, 6);
		System.out.println("Minimum index is " + m);
	}
}
