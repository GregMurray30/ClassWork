class Color {
	private int r, g, b;
	Color() {
		r = 0;
		g = 0;
		b = 0;
	}
	Color(int r0, int g0, int b0) {
		r = r0;
		g = g0;
		b = b0;
	}
	int getR() { return r; }
	int getG() { return g; }
	int getB() { return b; }
	Color setR(int r0) {
		r = r0;
		return this;
	}
	Color setG(int g0) {
		g = g0;
		return this;
	}
	Color setB(int b0) {
		b = b0;
		return this;
	}
	public String toString() {
		return "R:" + r + " G:" + g + " B:" + b;
	}
}


class ThisChain {
	public static void main(String[] args) {
		Color c;
		
		c = new Color(255, 0, 0);
		c.setR(100).setG(30).setB(200);
		System.out.println(c);
	}
}
