import java.util.Random;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;    
import javax.swing.event.*;    

class Board {
	private int w, h;
	private boolean[][] b;
	Board(int width, int height) {
		w = width; h = height;
		b = new boolean[h][w];
	}
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for (int r = 0; r < h; r++) {
			for (int c = 0; c < w; c++) {
				if (b[r][c]) {
					sb.append("@");
				} else {
					sb.append(".");
				}
			}
			sb.append("\n");
		}
		return sb.toString();
	}
	boolean get(int r, int c) {
		if (r < 0 || r >= h || c < 0 || c >= w) {
			return false;
		}
		return b[r][c];
	}
	void set(int r, int c, boolean value) {
		b[r][c] = value;
	}
	int countAtOffset(int r, int c, int deltar, int deltac) {
		if (get(r + deltar, c + deltac)) {
			return 1;
		} else {
			return 0;
		}
	}
	int neighbors(int r, int c) {
		int count = 0;
		for (int dr = -1; dr <= 1; dr++) {
			for (int dc = -1; dc <=1; dc++) {
				if (dr != 0 || dc != 0) {
					count += countAtOffset(r, c, dr, dc);
				}
			}
		}
		return count;
	}
	void clear() {
		b = new boolean[h][w];
	}
	void initialize(int n) {
		Random rnd = new Random();
		for (int i = 0; i < n; i++) {
			int r = rnd.nextInt(h);
			int c = rnd.nextInt(w);
			b[r][c] = true;
		}
	}
	void tick() {
		boolean [][] nextgen = new boolean[h][w];
		for (int r = 0; r < h; r++) {
			for (int c = 0; c < w; c++) {
				int n = neighbors(r, c);
				if (b[r][c]) {
					if (n < 2 || n >= 4) {
						nextgen[r][c] = false;
					} else {
						nextgen[r][c] = true;
					}
				} else {
					if (n == 3) {
						nextgen[r][c] = true;
					} else {
						nextgen[r][c] = false;
					}
				}
			}
		}
		// Copy back nextgen
		for (int r = 0; r < h; r++) {
			for (int c = 0; c < w; c++) {
				b[r][c] = nextgen[r][c];
			}
		}
	}
}

class LifePanel extends JPanel {
	Board b;
	LifePanel() {
		b = new Board(100, 100);
		b.initialize(10000);
		setPreferredSize(new Dimension(400, 400));
	}
	public void paint(Graphics g) {
		g.clearRect(0, 0, 400, 400);
		for(int r = 0; r < 100; r++) {
			for(int c = 0; c < 100; c++) {
				if (b.get(r, c)) {
					g.fillRect(c * 4, r * 4, 4, 4);
				}
			}
		}
		b.tick();
	}
	public void restart() {
		b.clear();
		b.initialize(10000);
	}
    public void clear() {
        b.clear();
    }
}

class LifeSwing implements Runnable {
	
	LifePanel lp;

	public void run() {
        JFrame frame = new JFrame("Life");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        lp = new LifePanel();
        Container pane = frame.getContentPane();
		pane.setLayout(new FlowLayout());
        pane.add(lp);
        JButton restart = new JButton("Restart");
        pane.add(restart);
        restart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				System.out.println("Click");
				lp.restart();
			}
		});
        JButton clear = new JButton("Clear");
        pane.add(clear);
        clear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                System.out.println("Clear clicked");
                lp.clear();
            }
        });
        frame.pack();
		frame.setVisible(true);
		ActionListener task = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				lp.repaint();
			}
		};
		Timer t = new Timer(100, task);
		t.start();
	}
    public static void main(String[] args) {
		LifeSwing demo = new LifeSwing();
		SwingUtilities.invokeLater(demo);
    }
}
