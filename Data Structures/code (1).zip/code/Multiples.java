
/* Print out multiples of 13 from 0 to 100.
 */

class Multiples {
	public static void main(String[] args) {
		int n = 0;
		while (n != 100) {
			System.out.println(n);
			n += 13000;
		}
	}
}
		
