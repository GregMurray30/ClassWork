
class DayOfWeek2 {
	public static void main(String[] args) {
		int day = 3; // Wednesday
		// Let's advance 10000 days
		day += 10000;
		day %= 7; // Keep it within 0-6
		switch (day) {
			case 0:
				System.out.println("Sunday");
				break;
			case 1:
				System.out.println("Monday");
				break;
			case 2:
				System.out.println("Tuesday");
				break;
			case 3:
				System.out.println("Wednesday");
				break;
			case 4:
				System.out.println("Thursday");
				break;
			case 5:
				System.out.println("Friday");
				break;
			case 6:
				System.out.println("Saturday");
				break;
			default:
				System.out.println("Illegal day");
				break;
		}
	}
}

