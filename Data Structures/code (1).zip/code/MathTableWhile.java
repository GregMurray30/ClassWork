
/* Print out a table of logarithms.
 */

class MathTableWhile {
	public static void main(String[] args) {
		int i = 0;
		while (i <= 1000) {
			double x = i / 1000.0;
			System.out.format("ln(%1.4f) = %f\n", x, Math.log(x));
			i++;
		}
	}
}


