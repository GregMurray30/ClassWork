class Pirate2 {
	public static void main(String[] args) {
		for(int x = 0; x <= 1000; x++) {
			for(int y = 0; y <= 1000; y++) {
				for(int z = 0; z <= 1000; z++) {
					for(int n = 2; n <= 1000; n++) {
						if(2*x+1==n && 3*y+1==n && 17*z+1==n) {
							System.out.format("%d", n);
						}
					}
				}
			}
		}
	}
}
