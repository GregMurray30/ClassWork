class DuplicateArray2 {

	static void showArray(int[] a) {
		for(int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}
	}

	static int[] duplicate(int[] from) {
		return from.clone();
	}

	public static void main(String[] args) {
		int[] data1 = {1, 2, 3, 4, 5, 6, 7};
		int[] data2;
		data2 = duplicate(data1);
		System.out.print("data1 = ");
		showArray(data1);
		System.out.println("");
		System.out.print("data2 = ");
		showArray(data2);
		System.out.println("");
	}
}
