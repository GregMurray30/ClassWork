class CrossOutTesting {
	
	/**
	 * Cross out a letter in a string with an X. BUGGY
	 * @param s
	 * 		input string
	 * @param pos
	 * 		position to cross out
	 * @return
	 * 		updated string
	 */
	static String cross(String s, int pos) {
		return s.substring(0, pos) + "X" +
			s.substring(pos + 1, s.length());
	}
	
	public static void main(String[] args) {
		String x = "Hello";
		System.out.println(cross(x, 0));
		System.out.println(cross(x, 1));
		System.out.println(cross(x, 2));
		System.out.println(cross(x, 3));
		System.out.println(cross(x, 4));
		System.out.println(x);
	}
}
