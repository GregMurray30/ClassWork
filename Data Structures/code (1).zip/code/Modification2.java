class Modification2 {

	static void messAround(int x) {
		System.out.println("There are " + x + " things.");
		x -= 1;
		System.out.println("Gulp. Now there are only " + x + " things.");
	}
	
	public static void main(String[] args) {
		int numApples = 50;
		int numOranges = 12;

		System.out.println("I've got " + numApples + " apples.");
		messAround(numApples);
		System.out.println("Oh no, now I have " + numApples + " apples.");
		
	}
}
