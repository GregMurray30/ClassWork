
import java.util.*;

class Pepy {
	public static void main(String[] args) {
		System.out.println("Let's solve Pepy's problem\n");
		
		// Generate a random integer, 1-6
		Random rnd = new Random();
		int n = 0;
		int rolls = 0;
		while (n != 1) {
			rolls++;
			n = rnd.nextInt(6) + 1;
		}
		
		System.out.format("It took %d rolls to get a one.\n", rolls);
	}
}

