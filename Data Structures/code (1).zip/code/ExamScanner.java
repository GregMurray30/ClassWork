import java.util.*;

class ExamScanner {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		for(int i = 0; i < 10; i++) {
			System.out.println(i);
			if (i == 8) {
				break;
			}
		}
		
		System.out.println("Hello");
		int x = scanner.nextInt();
		System.out.println("Goodbye");
	}
}
