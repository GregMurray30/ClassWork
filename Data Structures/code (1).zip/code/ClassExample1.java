class ClassExample1 {
	
	static int foo(int x) {
		x = x + 3;
		return x;
	}
	
	public static void main(String[] args) {
		int y = 10;
		foo(y);
		System.out.println(y);
	}
}
// What does it print?
// A. 10
// B. 13
// C. 16
// D. Some other number
// E. It will crash

