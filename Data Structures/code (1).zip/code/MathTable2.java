
/* Print out a table of sine.
 */

class MathTable2 {
	public static void main(String[] args) {
		for(int i = 0; i <= 1000; i++) {
			double x = i / 1000.0 * 2.0 * Math.PI;
			System.out.format("sin(%1.4f) = %f\n", x, Math.sin(x));
		}
	}
}


