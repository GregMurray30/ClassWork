class ArraySum2 {
	
	static int sum(String[] theArray) {
		int s = 0;
		for(int i = 0; i < theArray.length; i++) {
			s += theArray[i];
		}
		return s;
	}
	public static void main(String[] args) {
		
		int[] a = {3, 2, 1};
		int total = sum(a);
		System.out.println(total);
	}
}
