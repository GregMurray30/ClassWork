class Counter {
	private int count;
	
	Counter(int startCount) {
		if (startCount < 0) {
			throw new Exception("Counter start value cannot be negative");
		}
		count = startCount;
	}
	int get() { return count; }
	void click() { count++; }
}

class Exception8 {
	
	public static void main(String[] args) {
		Counter cnt = new Counter(-10);
		System.out.println(cnt.get());
	}
}

