class ExamModulus {
	public static void main(String[] args) {
		int x = 3;
		x % 2 % 2 % 2;
		System.out.println(x);
	}
}
