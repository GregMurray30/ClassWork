
/* How many asterisks are printed?
 * A. 0
 * B. 30
 * C. 40
 * D. 261
 * E. 300
 */

class ForCount1 {
	public static void main(String[] args) {
		for(int i = 0; i < 10; i++) {
			for(int j = 0; j < 30; j++) {
				System.out.print("*");
			}
			System.out.print("\n");
		}
	}
}


