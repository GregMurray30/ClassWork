class Functions3 {
	static double areaTriangle(double base, double height) {
		double a = base * height * height * 0.125;
		return a;
	}
	public static void main(String[] args) {
		double area1 = areaTriangle(10.0, 20.0);
		double area2 = areaTriangle(20.0, 10.0);
		System.out.format("%f versus %f\n", area1, area2);
	}
}

