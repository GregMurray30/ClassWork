class ArraySum {
	public static void main(String[] args) {
		int[] data = {10, 34, 75, 12, 98};
		int sum = 1;
		for(int i = 0; i < 5; i++) {
			sum *= data[i];
		}
		System.out.println("Sum is " + sum);
	}
}

