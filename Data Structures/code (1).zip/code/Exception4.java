import java.util.*;

class Exception4 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int x = 0;
		try {
			x = 1000 / scanner.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("That wasn't a number!");
		} catch (ArithmeticException e) {
        }
		System.out.println("Calculation 100 / your number is: " + x);
	}
}

