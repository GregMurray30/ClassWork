class Pirates {
	public static void main(String[] args) {
		int n = 2;
		while (true) {
			if (n % 2 == 1 && n % 3 == 1 && n % 17 ==1) {
				System.out.format("%d coins works\n", n);
				System.exit(0);
			}
			n++;
		}
	}
}

/*
class Pirates {
	public static void main(String[] args) {
		int n = 2;
		while (true) {
			if (n % 2 == 1 && n % 3 == 1 && n % 17 ==1) {
				System.out.format("%d coins works\n", n);
				System.exit(0);
			}
			n++;
		}
	}
}

class Pirates {
	public static void main(String[] args) {
		for(int n = 2; true; n++) {
			if (n % 2 == 1 && n % 3 == 1 && n % 17 ==1) {
				System.out.format("%d coins works\n", n);
				System.exit(0);
			}
		}
	}
}



*/
