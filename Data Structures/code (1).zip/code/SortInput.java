import java.util.*;

class SortInput {
	public static void main(String[] args) {
		int a, b, c, t;
		
		System.out.println("Enter 3 numbers to sort");
		Scanner scanner = new Scanner(System.in);
		a = scanner.nextInt();
		b = scanner.nextInt();
		c = scanner.nextInt();

		if (a > b) {
			// exchange a and b
			t = a;
			a = b;
			b = t;
		}
		if (b > c) {
			// exchange b and c
			t = b;
			b = c;
			c = t;
		}
		if (a > b) {
			// exchange a and b
			t = a;
			a = b;
			b = t;
		}

		System.out.format("Sorted order is %d, %d, %d\n", a, b, c);
	}
}
