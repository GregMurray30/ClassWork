import java.util.Scanner;

class Donut {
	public static void main(String[] args) {
		System.out.println("How many donuts?");
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		// Brute force look for solution
		for(int i = 0; i < 250000; i++) {
			// Trying i packs of 4
			if (i * 4 == n) {
				System.out.format("Order %d packs of 4\n", i);
				System.exit(0);
			}
		}
		System.out.println("Can't order that many");
	}
}

// Things to do:
// Update upper limit of loop to <= n/4
// Be smarter, use division
