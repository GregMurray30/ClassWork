if (temperature < 32)
	System.out.println("Warning: below freezing");
System.out.println("It's cold tonight");

if (temperature < 32) {
	System.out.println("Warning: below freezing");
	System.out.println("Pretty cold, eh?");
	System.out.println("Warning!");
}

