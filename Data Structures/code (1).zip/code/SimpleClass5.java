class Counter {
	private int value;		// instance variable
	int value1;
	Counter() {		// constructor
		value = 0;
	}
	public int get() {		// accessor method
		return value;
	}
	public void click() {
		value = (value + 1) % 100;
	}
}

class SimpleClass5 {
	public static void main(String[] args) {
		Counter c1 = new Counter();
		Counter c2 = new Counter();

		c1.click();
		c2.click();
		c2.click();
		c2.click();
		System.out.println(c1.get());
		System.out.println(c2.get());
		System.out.println(c1.value1);
	}
}
