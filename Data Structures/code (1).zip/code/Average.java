import java.util.*;

class Average {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter numbers to average, followed by 0.");
		double number, total = 0.0;
		int count = 0;
		number = scanner.nextDouble();
		while (number != 0.0) {
			total += number;
			count++;
			number = scanner.nextDouble();
		}
		System.out.println("There were " + count
			+ " numbers entered.");
		double avg = total / count;
		System.out.format("Average = %f\n", avg);
	}
}

// A. 0  B. Infinity C. NaN D. Program stops with exception

