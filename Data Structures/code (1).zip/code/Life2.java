class Board {
	private int w, h;
	private boolean[][] b;
	Board(int width, int height) {
		w = width; h = height;
		b = new boolean[h][w];
	}
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for (int r = 0; r < h; r++) {
			for (int c = 0; c < w; c++) {
				if (b[r][c]) {
					sb.append("@");
				} else {
					sb.append(".");
				}
			}
			sb.append("\n");
		}
		return sb.toString();
	}
	boolean get(int r, int c) {
		if (r < 0 || r >= h || c < 0 || c >= w) {
			return false;
		}
		return b[r][c];
	}
	void set(int r, int c, boolean value) {
		b[r][c] = value;
	}
	int countAtOffset(int r, int c, int deltar, int deltac) {
		if (get(r + deltar, c + deltac)) {
			return 1;
		} else {
			return 0;
		}
	}
	int neighbors(int r, int c) {
		int count = 0;
		for (int dr = -1; dr <= 1; dr++) {
			for (int dc = -1; dc <=1; dc++) {
				if (dr != 0 || dc != 0) {
					count += countAtOffset(r, c, dr, dc);
				}
			}
		}
		return count;
	}
	void tick() {
		boolean [][] nextgen = new boolean[h][w];
		for (int r = 0; r < h; r++) {
			for (int c = 0; c < w; c++) {
				int n = neighbors(r, c);
				if (b[r][c]) {
					if (n < 2 || n >= 4) {
						nextgen[r][c] = false;
					} else {
						nextgen[r][c] = true;
					}
				} else {
					if (n == 3) {
						nextgen[r][c] = true;
					} else {
						nextgen[r][c] = false;
					}
				}
			}
		}
		// Copy back nextgen
		for (int r = 0; r < h; r++) {
			for (int c = 0; c < w; c++) {
				b[r][c] = nextgen[r][c];
			}
		}
	}
}
	

class Life2 {
	public static void main(String[] args) {
		Board brd = new Board(5, 5);
		brd.set(2, 1, true);
		brd.set(2, 2, true);
		brd.set(2, 3, true);
		System.out.println(brd);
		brd.tick();
		System.out.println(brd);
		brd.tick();
		System.out.println(brd);
	}
}
