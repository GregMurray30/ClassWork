
//Suit class - a playing card attribute
class Suit {
  static final int CLUBS = 1;
  static final int DIAMONDS = 2;
  static final int HEARTS = 3;
  static final int SPADES = 4;   
  int suitValue;    
  Suit(int i) { suitValue = i; }
  public String toString() {
    switch (suitValue) {      
      case CLUBS: return "clubs";       
      case DIAMONDS: return "diamonds";
      case HEARTS: return "hearts";
      case SPADES: return "spades";
      default: return "error";
    }
  }
}

//Card class - a playing card
class Card {
  Suit suit;   
  Pips pip;   
  Card(Suit s, Pips p) { suit = s; pip =p; }
  Card(Card c) { suit = c.suit; pip = c.pip; } 
  public  String toString() {
    return pip.toString() +":" 
        +  suit.toString()+ " ";  
  }   
}

//Deck class- a deck of playing cards
class Deck {
  Card[] deck;
  Deck() {
    deck = new Card[52];
    for (int i = 0; i < deck.length; i++)
      deck[i] = new Card(new Suit(i / 13 + 1),
                      new Pips(i % 13 + 1));   
  }
  void shuffle() {   
    for (int i = 0; i < deck.length; i++){
      int k = (int)(Math.random() * 52);
      Card t = new Card(deck[i]);
      deck[i] = deck[k];
      deck[k] = t;    
    } 
  } 
  public  String toString()  { 
    String t = ""; 
    for (int i = 0; i < 52; i++)
      if ( (i + 1) % 5 == 0)
        t = t + "\n" + deck[i];
      else     
        t = t + deck[i];
      return t;
  }
}

