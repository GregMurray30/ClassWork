
	Card[] deck;			// array
    ArrayList<Card> deck;	// ArrayList
    
    deck[i]					// array
    deck.get(i)				// ArrayList
    
    deck[i] = ...			// array
    deck.set(i, ...)		// ArrayList
    
    deck.length				// array
    deck.size()				// ArrayList
    
    deck.add(c)				// ArrayList
    
	deck.remove(i)			// ArrayList

