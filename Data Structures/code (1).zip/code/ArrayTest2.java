class ArrayTest2 {
	public static void main(String[] args) {
		
		int[] a = new int[5];
		a[0] = 1;
		for(int i = 0; i < 5; i++) {
			a[i] = i + a[i - 1];
		}
		System.out.println(a[4]);
	}
}
