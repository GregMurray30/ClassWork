//Suit class - a playing card attribute
class Suit {

    static final int CLUBS = 1;
    static final int DIAMONDS = 2;
    static final int HEARTS = 3;
    static final int SPADES = 4;   

    int suitValue;

    Suit(int i) {
        suitValue = i;
    }

    public String toString() {
        switch (suitValue) {      
            case CLUBS: return "clubs";       
            case DIAMONDS: return "diamonds";
            case HEARTS: return "hearts";
            case SPADES: return "spades";
            default: return "error";
        }
    }
}

//Pips class - a playing card attribute
class Pips {
    int p;

    Pips(int i) { p = i; }

    public String toString() {
        if (p > 1 && p < 11)
            return new Integer(p).toString();
        else if (p == 1)
            return "Ace";
        else if (p == 11)
            return "Jack";
        else if (p == 12)
            return "Queen";
        else if (p == 13)
            return "King";
        else return "error";
    }
}

//Card class - a playing card
class Card {

    Suit suit;   
    Pips pip;   

    Card(Suit s, Pips p) {
        suit = s;
        pip =p;
    }
    Card(Card c) {
        // Copy existing card
        suit = c.suit;
        pip = c.pip;
    }

    public String toString() {
        return pip.toString() + ":" +  suit.toString()+ " ";  
    }   
}

//Deck class- a deck of playing cards
class Deck {

    Card[] deck;

    Deck() {
        deck = new Card[52];
        for (int i = 0; i < deck.length; i++) {
            deck[i] = new Card(new Suit(i / 13 + 1),
                               new Pips(i % 13 + 1));
        }
    }

    void shuffle() {   
        for (int i = 0; i < deck.length; i++) {
            int k = (int)(Math.random() * 52);
            Card t = new Card(deck[i]);
            deck[i] = deck[k];
            deck[k] = t;    
        }
    }

	Card deal() {
		// Hmm, arrays have fixed size so we need to copy
		// Deal off card in top position (largest index)
		Card result = deck[deck.length - 1];
		int num = deck.length;
		Card[] newDeck = new Card[num - 1];
		for(int i = 0; i < num - 1; i++) {
			newDeck[i] = deck[i];
		}
		deck = newDeck;
		return result;
	}

    public String toString() {
        String t = ""; 
        for (int i = 0; i < deck.length; i++) {
            if ( (i + 1) % 5 == 0) {
                t = t + "\n" + deck[i];
            } else {
                t = t + deck[i];
            }
        }
        return t;
    }
}

// Main class
class BlackJack2 {
    public static void main(String[] args) {
        System.out.println("Let's play some blackjack");

        Deck d = new Deck();        

        d.shuffle();
        System.out.println(d);

        Card c1 = d.deal();
        Card c2 = d.deal();
        System.out.println("\n");
        System.out.println("You got: " + c1 + " and " + c2);
        System.out.println(d);
    }
}
