
import java.util.*;

class SimpleInput {
	public static void main(String[] args) {
		System.out.println("Enter a number");
		Scanner scan = new Scanner(System.in);
		int x = scan.nextInt();
		float y = 2.3;
		int z = y;
		System.out.format("You entered the number %d\n", x);
		System.out.format("A floating point number %f\n", 1.5);
	}
}

