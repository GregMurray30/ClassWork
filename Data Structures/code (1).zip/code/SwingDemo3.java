import java.awt.*;
import java.awt.event.*;
import javax.swing.*;    
import javax.swing.event.*;    

class Star extends JPanel {
	int x;
	Star() {
		x = 0;
		setPreferredSize(new Dimension(200, 200));
	}
	public void paint(Graphics g) {
		x += 10;
		if (x > 200) {
			x = 0;
		}
		g.clearRect(0, 0, 200, 200);
		g.fillRect(x, 100, 20, 20);
	}
}

class SwingDemo3 implements Runnable {
	
	Star star;

	public void run() {
        JFrame frame = new JFrame("Life");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        star = new Star();
        frame.getContentPane().add(star);
        frame.pack();
		frame.setVisible(true);
		ActionListener task = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				star.repaint();
			}
		};
		Timer t = new Timer(100, task);
		t.start();
	}
    public static void main(String[] args) {
		SwingDemo3 demo = new SwingDemo3();
		SwingUtilities.invokeLater(demo);
    }
}
