import java.awt.*;
import javax.swing.*;        

class Star extends JPanel {
	int x;
	Star() {
		x = 0;
		setPreferredSize(new Dimension(200, 200));
	}
	public void paint(Graphics g) {
		x += 10;
		if (x > 200) {
			x = 0;
		}
		g.fillRect(x, 100, 20, 20);
	}
}

class SwingDemo2 {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Life");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Star star = new Star();
        frame.getContentPane().add(star);
        frame.pack();
		frame.setVisible(true);
    }
}
