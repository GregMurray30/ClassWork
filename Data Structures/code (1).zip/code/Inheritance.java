class Animal {
	void talk() {
		System.out.println("I'm an unknown mysterious animal");
	}
	boolean hasFur() {
		return true; // why not
	}
}

class Dog extends Animal {
	void talk() {
		System.out.println("Woof!");
	}
}

class Duck extends Animal {
	void talk() {
		System.out.println("Quack!");
	}
	boolean hasFur() {
		return false;
	}
}

class Inheritance {
	public static void main(String[] args) {
		Dog steve = new Dog();
		steve.talk();
		System.out.println("Steve has fur: " + steve.hasFur());
	}
}
