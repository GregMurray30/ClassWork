import java.awt.*;
import javax.swing.*;        

class Star extends JPanel {
	Star() {
		setPreferredSize(new Dimension(200, 200));
	}
	public void paint(Graphics g) {
		g.fillRect(100, 100, 20, 20);
	}
}

class SwingDemo {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Life");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Star star = new Star();
        frame.getContentPane().add(star);
        frame.pack();
		frame.setVisible(true);
    }
}
