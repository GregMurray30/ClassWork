import java.util.*;

//Suit class - a playing card attribute
class Suit {

    static final int CLUBS = 1;
    static final int DIAMONDS = 2;
    static final int HEARTS = 3;
    static final int SPADES = 4;   

    int suitValue;

    Suit(int i) {
        suitValue = i;
    }

    public String toString() {
        switch (suitValue) {      
            case CLUBS: return "clubs";       
            case DIAMONDS: return "diamonds";
            case HEARTS: return "hearts";
            case SPADES: return "spades";
            default: return "error";
        }
    }
}

//Pips class - a playing card attribute
class Pips {
    int p;

    Pips(int i) { p = i; }

    public String toString() {
        if (p > 1 && p < 11)
            return new Integer(p).toString();
        else if (p == 1)
            return "Ace";
        else if (p == 11)
            return "Jack";
        else if (p == 12)
            return "Queen";
        else if (p == 13)
            return "King";
        else return "error";
    }
}

//Card class - a playing card
class Card {

    Suit suit;   
    Pips pip;   

    Card(Suit s, Pips p) {
        suit = s;
        pip =p;
    }
    Card(Card c) {
        // Copy existing card
        suit = c.suit;
        pip = c.pip;
    }

    public String toString() {
        return pip.toString() + ":" +  suit.toString()+ " ";  
    }   
}

//Deck class- a deck of playing cards
class Deck {

    ArrayList<Card> deck;

    Deck() {
        deck = new ArrayList<Card>();
        for (int i = 0; i < 52; i++) {
            deck.add(new Card(new Suit(i / 13 + 1),
                              new Pips(i % 13 + 1)));
        }
    }

    void shuffle() {   
        for (int i = 0; i < deck.size(); i++) {
            int k = (int)(Math.random() * 52);
            Card t = new Card(deck.get(i));
            deck.set(i, deck.get(k));
            deck.set(k, t);
        }
    }

	Card deal() {
		// Deal card at index 0
		Card result = deck.get(0);
		deck.remove(0); // That's handy
		return result;
	}

    public String toString() {
        String t = ""; 
        for (int i = 0; i < deck.size(); i++) {
            if ( (i + 1) % 5 == 0) {
                t = t + "\n" + deck.get(i);
            } else {
                t = t + deck.get(i);
            }
        }
        return t;
    }
}

// Main class
class BlackJack3 {
    public static void main(String[] args) {
        System.out.println("Let's play some blackjack");

        Deck d = new Deck();        

        d.shuffle();
        System.out.println(d);

        Card c1 = d.deal();
        Card c2 = d.deal();
        System.out.println("\n");
        System.out.println("You got: " + c1 + " and " + c2);
        System.out.println(d);
    }
}
