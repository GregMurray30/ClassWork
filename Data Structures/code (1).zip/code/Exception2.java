import java.util.*;

class Exception2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int x = 0;
		try {
			x = scanner.nextInt();
		} catch (Exception e) {
			System.out.println("That wasn't a number!");
		}
		System.out.println("You entered the number: " + x);
	}
}
