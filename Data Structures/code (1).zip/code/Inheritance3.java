class Animal {
	void talk() {
		System.out.println("I'm an unknown mysterious animal");
	}
	boolean hasFur() {
		return true; // why not
	}
}

class Dog extends Animal {
	void talk() {
		System.out.println("Woof!");
	}
	void bite() {
		System.out.println("<chomp>");
	}
}

class Duck extends Animal {
	void talk() {
		System.out.println("Quack!");
	}
	boolean hasFur() {
		return false;
	}
}

class Inheritance3 {
	public static void main(String[] args) {
		Dog steve = new Dog();
		steve.bite();
		Animal arnold = new Animal();
		arnold.bite();
	}
}
