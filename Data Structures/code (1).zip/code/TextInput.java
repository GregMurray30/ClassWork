import java.awt.*; 
import javax.swing.*;
import java.awt.event.*;

class Echo implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    JTextField source = (JTextField)e.getSource();
    String text = source.getText();
    System.out.println(text);
  }
}

class TextInput { 
  public static void main(String[] args) { 
    JFrame frame = new JFrame("TextInput"); 
    Container pane = frame.getContentPane();
    JTextField input = new 
       JTextField("Edit this text then hit <return>");
    Echo listener = new Echo();
//    input.addActionListener(listener); 
    pane.add(input); 
    frame.pack();
    frame.show();
  }
}

/* What will happen with this change?
 * A. Same behavior
 * B. Nothing happens when you press enter
 * C. Program doesn't work at all (no window shows up)
 * D. Something else
 */
