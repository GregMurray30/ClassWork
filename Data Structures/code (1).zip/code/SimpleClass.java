class Counter {
	int value;		// instance variable
	void reset() {	// mutator method
		value = 0;
	}
	int get() {		// accessor method
		return value;
	}
	void click() {
		value = (value + 1) % 100;
	}
}

class SimpleClass {
	public static void main(String[] args) {
		Counter c = new Counter();
		
		c.reset();
		c.click();
		c.click();
		c.click();
		System.out.println(c.get());
	}
}
