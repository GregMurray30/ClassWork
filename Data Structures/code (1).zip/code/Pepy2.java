
import java.util.*;

class Pepy2 {
	public static void main(String[] args) {
		System.out.println("Let's solve Pepy's problem\n");
		
		// Generate a random integer, 1-6
		Random rnd = new Random();

		int numOnes = 0;
		for(int i = 0; i < 6; i++) {
			int n = rnd.nextInt(6) + 1;
			if (n == 1) {
				numOnes++;
			}
		}

		System.out.format("We rolled %d ones out of 6 dice.\n", numOnes);
	}
}

