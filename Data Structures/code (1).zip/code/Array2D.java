
class Array2D {
	public static void main(String[] args) {
		
		int [][] board = new int[3][3];
		
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				board[i][j] = i + j;
			}
		}
		System.out.println(board);
	}
}
