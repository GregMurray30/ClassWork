class Functions2 {
	static void derp(int n) {
		for (int i = 0; i < n; i++) {
			System.out.println("Herp!");
			System.out.println("Derp!");
		}
	}
	public static void main(String[] args) {
		System.out.println("Welcome, Derpina.");
		derp(5);
		System.out.println("Goodbye, Derpina.");
		System.out.println("Thank you for your contribution.");
	}
}
