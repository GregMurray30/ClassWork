
import java.util.*;

class CircleArea {
	public static void main(String[] args) {
		System.out.println("What is the radius?");
		Scanner scan = new Scanner(System.in);
		double r = scan.nextDouble();
		System.out.format("r = %f\n", r);
		double area = Math.PI * r * r;
		System.out.format("area = %f\n", area);
	}
}

