class TestCopy {

	static void showArray(int[] a) {
		for(int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}
	}

	static void copy(int[] from, int[] to) {
		for(int i = 0; i < to.length; i++) {
			to[i] = from[i];
		}
	}

	public static void main(String[] args) {
		int[] data1 = {1, 2, 3, 4};
		int[] data2 = {8, 9, 10, 11, 12, 13, 14};
		copy(data1, data2);
		System.out.print("data1 = ");
		showArray(data1);
		System.out.println("");
		System.out.print("data2 = ");
		showArray(data2);
		System.out.println("");
	}
}
