

class WhileLove {
	public static void main(String[] args) {
		int love = 0;
		while (love < 5) {
			System.out.println("Love");
			love++;
		}
	}
}


