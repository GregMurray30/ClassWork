import java.util.Scanner;

class Doubling {
	public static void main(String[] args) {
		System.out.println("What is the number?");
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int doublings = 0;
		int i = 1;
		while (i < n) {
			i = i * 2;
			doublings++;
		}
		System.out.format("It takes %d doublings\n", doublings);
	}
}

// Rewrite into a for loop
