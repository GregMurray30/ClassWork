import java.util.Scanner;

class Donut4 {
	public static void main(String[] args) {
		System.out.println("How many donuts?");
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		for (int i = 0; i <= n / 4; i++) {
			// Try i packs of 4
			for (int j = 0; j <= n / 13; j++) {
				// Try j packs of 13
				if (i * 4 + j * 13 == n) {
					System.out.format("Order %d packs of 4, %d packs of 13\n",
						i, j);
					System.exit(0);
				}
				// Keep going, try next possibility
			}
		}
		System.out.println("Can't order that many");
	}
}

