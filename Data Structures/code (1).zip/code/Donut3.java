import java.util.Scanner;

class Donut3 {
	public static void main(String[] args) {
		System.out.println("How many donuts?");
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		for (int i = 0; i <= n / 13; i++) {
			// Try i packs of 13
			// How many are left?
			int left = n - i * 13;
			// Can we use up all that's left with 4 packs?
			if (left % 4 == 0) {
				System.out.format("Order %d packs of 13, %d packs of 4\n",
					i, left / 4);
				System.exit(0);
			}
			// Keep going, try next possibility
		}
		System.out.println("Can't order that many");
	}
}
