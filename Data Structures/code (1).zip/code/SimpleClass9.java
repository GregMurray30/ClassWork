class Counter {
	private int value;
	static int maxCount = 3;

	Counter() {
		value = 0;
	}
	public int get() {
		return value;
	}
	public void click() {
		value++;
		if (value >= maxCount) {
			value = 0;
		}
	}
	public String toString() {
		return "Count is " + value;
	}
	public static int getMaxCount() {
		return maxCount;
	}
}

class SimpleClass9 {
	
	public static void main(String[] args) {
		System.out.println(Counter.getMaxCount());
	}
}

// Is this legal???
// A. Yes
// B. No
// C. It will compile and run but give weird answers
