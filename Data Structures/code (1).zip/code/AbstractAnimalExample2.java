abstract class Animal {
	protected String dna;
	Animal() {
		dna = "ACGTACGT";
	}
	abstract public void speak();
	abstract public int numLegs();
}

abstract class Mammal extends Animal {
	protected double lungCapacity;
	protected double bloodTemp;
	abstract public void breath();
	abstract public void groom();
	Mammal() {
		dna = dna + "GGTTAACC";
	}
}

class Dog extends Mammal {
	private int numTicks;
	Dog() {
		lungCapacity = 1.3;
		bloodTemp = 32.1;
		numTicks = 5;
	}
	public void speak() {
		System.out.println("Woof! " + dna);
	}
	public int numLegs() {
		return 4;
	}
	public void breath() {
		lungCapacity += 0.2;
	}
	public void groom() {
		numTicks--;
	}
}

class AbstractAnimalExample2 {
	public static void main(String[] args) {
		Dog doug = new Dog();
		doug.speak();
	}
}
