class Functions4 {
	public static void main(String[] args) {
		System.out.println("Hello again, Derpina.");
		String message = "Derp!";
		derp(5);
	}
	static double derp(int n) {
		// This does NOT work, message is not in scope
		for(int i = 0; i < n; i++) {
			System.out.println(message);
		}
	}
}

