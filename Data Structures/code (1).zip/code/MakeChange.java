import java.util.*;

/* An item costs 0-100 cents, the customer pays with a dollar.
 * What change do they receive if we just use dimes and pennies?
 */

class MakeChange {
	public static void main(String[] args) {
		int price, change, dimes, pennies;
		
		System.out.println("How many cents is the item?");
		Scanner scanner = new Scanner(System.in);
		price = scanner.nextInt();
		change = 100 - price; // total change they will receive
		dimes = change / 10; // how many dimes to give
		pennies = change % 10; // how many pennies to give
		System.out.format("Change is %d dimes and %d pennies.\n",
			dimes, pennies);
	}
}
