
int count = 5, total = 100;
String sentence = "The cow jumped over the moon.";
boolean done = false;
Button clickToExit =
	new Button("Exit NOW");



