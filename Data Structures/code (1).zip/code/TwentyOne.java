import java.util.*;


class TwentyOne {

	/**
	 * getUserMove reads in user move, only accepting legal inputs
	 * @param numberOfStones
	 * 		The number of stones remaining in the pile.
	 * @return
	 * 		The number of stones to be removed by player.
	 */
	static int getUserMove(int numberOfStones) {
		System.out.println("There are " + numberOfStones + " left.");
		System.out.println("How many do you remove?");
		Scanner scanner = new Scanner(System.in);
		int number = scanner.nextInt();
		while (number < 1 || number > 3 || number > numberOfStones) {
			System.out.println("Cheater! Try again.");
			number = scanner.nextInt();
		}
		return number;
	}

	/**
	 * computerMove completes one move by the computer
	 * @param numberOfStones
	 * 		The number of stones remaining in the pile.
	 * @return
	 * 		The number of stones remaining after the computer's move.
	 */
	static int computerMove(int numberOfStones) {
		int number = 1;
		if (numberOfStones <= 3) {
			number = numberOfStones;
		} else {
			// Cunning strategy
			number = numberOfStones % 4;
			if (number == 0) {
				// Fallback strategy
				number = 1;
			}
		}
		System.out.println("I choose to remove " + number + " stones.");
		return numberOfStones - number;
	}

	/**
	 * playerMove completes one move by the player
	 * @param numberOfStones
	 * 		The number of stones remaining in the pile.
	 * @return
	 * 		The number of stones remaining after the user moves.
	 */
	static int playerMove(int numberOfStones) {
		int move = getUserMove(numberOfStones);
		numberOfStones -= move;
		System.out.println("There are " + numberOfStones + " stones left.");
		return numberOfStones;
	}

	/**
	 * printInstructions shows how to play
	 */
	static void printInstructions() {
		System.out.println("Try to remove the last stone. You may remove "
		+ "1 to 3 stones per move.");
		System.out.println("I will crush you, by the way.");
	}

	public static void main(String[] args) {
		printInstructions();
		// Create initial pile
		int stones = 21;
		boolean playerMovedLast = false;
		while (stones > 0) {
			stones = playerMove(stones);
			playerMovedLast = true;
			if (stones > 0) {
				stones = computerMove(stones);
				playerMovedLast = false;
			}
		}
		if (playerMovedLast) {
			System.out.println("How is this possible, you win!");
		} else {
			System.out.println("Ha, I win.");
		}
	}
}
