	int x = 12, y = 32, min, max;
	
	if (x < y)
		min = x;
	else
		min = y;
	
	if (x < y) {
		min = x;
	} else {
		min = y;
	}
	
	if (x < y)
		min = x;
		max = y; // OOPS!! (compile error)
	else
		min = y;

	if (x < y)
		min = x;
	else
		min = y;
		max = y; // OOPS!! (no error!!!)


	if (x < y) {
		min = x;
		max = y;
	} else {
		min = y;
		max = x;
	}
	

	double temperature = 35.0; // Fahrenheit temperature

	if (temperature < 32.0) {
		System.out.println("It's freezing out!");
	} else {
		System.out.println("Not that cold, really.");
		if (temperature > 70.0) {
			System.out.println("Pretty nice, actually.");
		}
	}

    int age = 23, price;
    
    if (age <= 12)
		price = 0;
	else if (age <= 65)
		price = 12;
	else
		price = 6;


    if (age <= 12) {
		price = 0;
	} else {
		if (age <= 65)
			price = 12;
		else
			price = 6;
	}

	price = 12;
	if (age <= 65)
		if (age <= 12)
			price = 0;
	else
		price = 6;


