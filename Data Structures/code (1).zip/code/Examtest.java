class Examtest {
	public static void main(String[] args) {
		int x = 10;
		int y = x++;
		
		System.out.println("y is now " + y + " while x is " + x);
	}
}
