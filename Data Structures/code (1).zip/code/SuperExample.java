class Dice {
	java.util.Random rnd;
	Dice() {
		rnd = new java.util.Random();
	}
	int roll() {
		return rnd.nextInt(6) + 1;
	}
}

class WeightedDice extends Dice {
	int roll() {
		int r = super.roll();
		if (r == 1) {
			r = super.roll();
		}
		return r;
	}
}

class SuperExample {
	public static void main(String[] args) {
		Dice d = new Dice();
		for(int i = 0; i < 60; i++) {
			System.out.print(d.roll());
		}
		System.out.println();
		Dice e = new WeightedDice();
		for(int i = 0; i < 60; i++) {
			System.out.print(e.roll());
		}
		System.out.println();
	}
}

