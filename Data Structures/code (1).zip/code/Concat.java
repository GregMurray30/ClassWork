class Concat {
	public static void main(String[] args) {
		String part1 = "Humpty Dumpty sat on a wall, ";
		String part2 = "Humpty Dumpty had a great fall, and died.\n";
		String part3 = "But he reanimated as an undead egg.";
		String sentence;
		
		int x = 5;
		
		x = 7;
		
		// What value does x have?
		// 7
		
		x = x + 1;
		
		// What value does x have?
		// 8
		
		sentence = part1.concat(part2);
		// What is sentence?
		// "Humpty Dumpty sat on a wall, Humpty Dumpty had a great fall, and died.\n"
		
		
		sentence = sentence.concat(part3);  // make new var?

		// "Humpty Dumpty sat on a wall, Humpty Dumpty had a great fall, and died.\nBut then he ranimated as an undead egg."

		System.out.println(sentence);
	}
}
