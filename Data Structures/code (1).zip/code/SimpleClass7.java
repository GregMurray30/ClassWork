class Counter {
	private int value;		// instance variable
	Counter() {		// constructor
		value = 0;
	}
	Counter(int startvalue) {
		// Alternate constructor
		value = startvalue;
	}
	public int get() {		// accessor method
		return value;
	}
	public void click() {
		value = (value + 1) % 100;
	}
}

class SimpleClass7 {
	
	static void messWithIt(Counter c) {
		c.click();
		c.click();
	}
	
	public static void main(String[] args) {
		Counter c1 = new Counter(10);

		c1.click();
		messWithIt(c1);
		messWithIt(c1);
		System.out.println(c1.get());
	}
}
