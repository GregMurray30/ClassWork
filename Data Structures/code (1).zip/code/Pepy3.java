
import java.util.*;

class Pepy3 {
	public static void main(String[] args) {
		System.out.println("Let's solve Pepy's problem\n");
		
		// Generate a random integer, 1-6
		Random rnd = new Random();

		int successes = 0;
		for (int trial = 0; trial < 10000000; trial++) {
			int numOnes = 0;
			for(int i = 0; i < 6; i++) {
				int n = rnd.nextInt(6) + 1;
				if (n == 1) {
					numOnes++;
				}
			}
			if (numOnes >= 1) {
				successes++;
			}
		}

		System.out.format("Got %d successes out of 10000000.\n", successes);
	}
}

