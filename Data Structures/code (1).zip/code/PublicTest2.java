class SuperClass {
	int sekrit = 5;
}

class DerivedClass extends SuperClass {
	DerivedClass() {
	}
}

class PublicTest2 {
	public static void main(String[] args) {
		DerivedClass o = new DerivedClass();
		System.out.println(o.sekrit);
	}
}
