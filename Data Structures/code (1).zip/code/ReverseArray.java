import java.util.*;

class ReverseArray {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("How many elements?");
		int num = scanner.nextInt();
		int[] array = new int[num];
		for(int i = 0; i < num; i++) {
			int x = scanner.nextInt();
			array[i] = x;
		}
		System.out.println("Reversed that would be:");
		for(int i = 0; i < num; i++) {
			System.out.println(array[num - i - 1]);
		}
	}
}
