class Concat2 {
	public static void main(String[] args) {
		String part1;
		String part2;
		String word = "clock";
		String sentence;

		part1 = "Hickory dickory dock, ";
		part2 = "the cat ran up the ";

		sentence = part1.concat(part2);
		System.out.println(sentence.concat("ladder"));
	}
}
