class SuperClass {
	private int sekrit;
}

class DerivedClass extends SuperClass {
	public int sekrit;
}

class PublicTest {
	public static void main(String[] args) {
		DerivedClass o = new DerivedClass();
		o.sekrit = 5;
		System.out.println(o.sekrit);
		SuperClass s = new DerivedClass();
		s.sekrit = 10;
	}
}
