class FunctionQuiz2 {
	public static void main(String[] args) {
		foo();
	}
	static void foo() {
		for(int i = 0; i < 5; i++) {
			if (i < 3) {
				bar();
			}
		}
	}
	static void bar() {
		for(int i = 0; i < 5; i++) {
			System.out.println("Spam");
			if (i == 3) return;
		}
	}
}

