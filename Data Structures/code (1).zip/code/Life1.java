class Board {
	private int w, h;
	private boolean[][] b;
	Board(int width, int height) {
		w = width; h = height;
		b = new boolean[h][w];
	}
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for (int r = 0; r < h; r++) {
			for (int c = 0; c < w; c++) {
				if (b[r][c]) {
					sb.append("@");
				} else {
					sb.append(".");
				}
			}
			sb.append("\n");
		}
		return sb.toString();
	}
	boolean get(int r, int c) {
		return b[r][c];
	}
	void set(int r, int c, boolean value) {
		b[r][c] = value;
	}
}
	

class Life1 {
	public static void main(String[] args) {
		Board brd = new Board(5, 5);
		brd.set(2, 1, true);
		brd.set(2, 2, true);
		brd.set(2, 3, true);
		System.out.println(brd);
	}
}
