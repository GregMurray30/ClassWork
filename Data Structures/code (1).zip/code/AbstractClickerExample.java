abstract class AbstractClicker {
	protected int value;
	void reset() {
		value = 0;
	}
	int get() {
		return value;
	}
	abstract void click();
}

class Clicker extends AbstractClicker {
	void click() {
		value = value + 1;
	}
}

class AbstractClickerExample {
	public static void main(String[] args) {
		Clicker c = new Clicker();
		c.click();
		c.click();
		c.click();
		System.out.println(c.get());
	}
}
