import java.util.*;

class SelectionSort {
	
	static void swap(int[] array, int index1, int index2) {
		int temp = array[index1];
		array[index1] = array[index2];
		array[index2] = temp;
	}

	static int findMinimum(int[] array, int low, int high) {
		int minLoc = 0;
		int minVal = array[0];
		for (int i = low; i <= high; i++) {
			if (array[i] < minVal) {
				minLoc = i;
				minVal = array[i];
			}
		}
		return minLoc;
	}
	
	static void selectionSort(int[] array) {
		for(int i = 0; i < array.length; i++) {
			int index = findMinimum(array, i, array.length - 1);
			System.out.println("DEBUG " + index);
			swap(array, i, index);
		}
	}
	
	public static void main(String[] args) {
		int[] scores = { 23, -3, 1, 55, 92, 8 };
		
		selectionSort(scores);
		
		System.out.println(Arrays.toString(scores));
	}
}
