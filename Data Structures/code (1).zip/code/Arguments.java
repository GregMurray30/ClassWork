class Arguments {
    public static void main(String[] args) {
        System.out.println("There were " + args.length + " arguments.");
        for(int i = 0; i < args.length; i++) {
            System.out.println(args[i]);
        }
    }
}
