
class Bottles {
	public static void main(String[] args) {
		int number = 9;
		while (number > 0) {
			System.out.println(number + " bottles of Scotch on the wall, "
				+ number + " bottles of Scotch,");
			System.out.println("Take one down, pass it around, ");
			number--;
			System.out.println(number + " bottles of Scotch on the wall.");
		}
		System.out.println("Party's over.");
	}
}

