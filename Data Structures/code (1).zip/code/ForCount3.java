
/* How many asterisks are printed?
 * A. 0
 * B. 1
 * C. 19
 * D. 20
 * E. 200
 */

class ForCount3 {
	public static void main(String[] args) {
		for(int i = 0; i < 10; i++) {
			for(int j = 0; j < 20; j++) {
				System.out.print("*");
			}
			System.out.print("\n");
			System.exit(0);
		}
	}
}


