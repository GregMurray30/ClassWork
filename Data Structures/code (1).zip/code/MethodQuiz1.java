class MethodQuiz1 {
	public static void main(String[] args) {
		
		String txt = "I, for one, welcome the alien overlords.";
		System.out.println(txt.length());
		System.out.println(txt.charAt(4));
		
	}
}
