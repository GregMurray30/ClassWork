import java.util.*;

class Exception1 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int x = scanner.nextInt();
		System.out.println("You entered the number: " + x);
	}
}
