
class Pirate3 {
	public static void main(String[] args) {
		for(int n = 18; n <= 1000000; n++) {
			if (n % 17 == 1) {
				if (n % 3 == 1) {
					if (n % 2 == 1) {
						System.out.println(n);
						System.exit(0);
					}
				}
			}
		}
	}
}
