
class DayOfWeek3 {
	public static void main(String[] args) {
		int day = 3; // Wednesday
		// Let's advance 10000 days
		day += 10000;
		day %= 7; // Keep it within 0-6
		switch (day) {
			case 0:
			case 6:
				System.out.println("Weekend");
				break;
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
				System.out.println("Non-weekend");
				break;
			default:
				System.out.println("Illegal day");
				break;
		}
	}
}

