class Sieve {
	
	static void crossOut(boolean[] array, int x) {
		for(int i = x + x; i < array.length; i += x) {
			array[i] = false;
		}
	}

	public static void main(String[] args) {
		
		int N = 10000000; // Maximum tested value
		boolean table[] = new boolean[N];
		for(int i = 0; i < N; i++) {
			table[i] = true;
		}
		table[0] = false;
		table[1] = false;
		for(int i = 2; i < Math.sqrt(N); i++) {
			if (table[i]) {
				crossOut(table, i);
			}
		}
		for(int i = 0; i < N; i++) {
			if (table[i]) {
				System.out.print(i + " ");
			}
		}
		System.out.println();
		
	}
}
