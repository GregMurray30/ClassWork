class Fallthrough {
	public static void main(String[] args) {
		int x = 100;
		x *= 2;
		x += 1;
		System.out.print("I love ");
		switch (x / 3) {
			case 0:
			case 1:
			case 66:
			case 100:
				System.out.print("furry ");
				break;
			case 67:
			case 101:
			case 201:
				System.out.print("cuddly ");
			case 80:
			case 202:
			case 300:
				System.out.print("adorable ");
			default:
				System.out.print("fuzzy ");
				break;
		}
		System.out.println("bunnies.");
	}
}
